#!/usr/bin/env bash
set -euo pipefail
cd /root/DesignB_cloud_package
mkdir -p reports/patch_backups/pcse/crop/nutrients reports/patch_backups/pcse/conf reports/patch_logs
log="reports/patch_logs/pcse_patch_apply_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$log") 2>&1
echo '[1] uploaded payload hashes'
sha256sum patch_payload/pcse/crop/nutrients/n_demand_uptake.py patch_payload/pcse/conf/Wofost81_NWLP_CWB_CNB.conf wofost_runtime/pcse_patch_inventory.csv wofost_runtime/pcse_patch_audit_summary.json wofost_runtime/pcse_patch_file_summary.csv wofost_runtime/pcse_patch_diffs/crop__nutrients__n_demand_uptake.py.diff wofost_runtime/pcse_patch_diffs/conf__Wofost81_NWLP_CWB_CNB.conf.diff
echo '[2] strict hash assertions'
echo '2f6d9e5dbc3d99c3b4e682a1abb5d63012634b991e2090a01ef2e7c8d8e629d5  patch_payload/pcse/crop/nutrients/n_demand_uptake.py' | sha256sum -c -
echo 'c6a4b1995c6f60e079af8a6f562e0f22728c67210517cfd1e58c4554641eca00  patch_payload/pcse/conf/Wofost81_NWLP_CWB_CNB.conf' | sha256sum -c -
echo '0dfd8ad7fccce02a9da327725faabda57dcd012297a8b988dd11444c3b2d7614  wofost_runtime/pcse_patch_inventory.csv' | sha256sum -c -
echo 'ec4f6cdd724506805824b694356db08555a42bd05152d8e1c2af8f3854f5a2a5  wofost_runtime/pcse_patch_diffs/crop__nutrients__n_demand_uptake.py.diff' | sha256sum -c -
echo '5029503d8e002b9581bc21f3b2cf91ab60484d150e4c3821e9b1bde473c669e9  wofost_runtime/pcse_patch_diffs/conf__Wofost81_NWLP_CWB_CNB.conf.diff' | sha256sum -c -
echo '[3] backup stock installed files'
cp -f venv_designb/lib/python3.10/site-packages/pcse/crop/nutrients/n_demand_uptake.py reports/patch_backups/pcse/crop/nutrients/n_demand_uptake.py.stock
cp -f venv_designb/lib/python3.10/site-packages/pcse/conf/Wofost81_NWLP_CWB_CNB.conf reports/patch_backups/pcse/conf/Wofost81_NWLP_CWB_CNB.conf.stock
sha256sum reports/patch_backups/pcse/crop/nutrients/n_demand_uptake.py.stock reports/patch_backups/pcse/conf/Wofost81_NWLP_CWB_CNB.conf.stock
echo '[4] apply two-file patch'
cp -f patch_payload/pcse/crop/nutrients/n_demand_uptake.py venv_designb/lib/python3.10/site-packages/pcse/crop/nutrients/n_demand_uptake.py
cp -f patch_payload/pcse/conf/Wofost81_NWLP_CWB_CNB.conf venv_designb/lib/python3.10/site-packages/pcse/conf/Wofost81_NWLP_CWB_CNB.conf
echo '[5] installed patched hashes'
sha256sum venv_designb/lib/python3.10/site-packages/pcse/crop/nutrients/n_demand_uptake.py venv_designb/lib/python3.10/site-packages/pcse/conf/Wofost81_NWLP_CWB_CNB.conf
echo '2f6d9e5dbc3d99c3b4e682a1abb5d63012634b991e2090a01ef2e7c8d8e629d5  venv_designb/lib/python3.10/site-packages/pcse/crop/nutrients/n_demand_uptake.py' | sha256sum -c -
echo 'c6a4b1995c6f60e079af8a6f562e0f22728c67210517cfd1e58c4554641eca00  venv_designb/lib/python3.10/site-packages/pcse/conf/Wofost81_NWLP_CWB_CNB.conf' | sha256sum -c -
echo '[6] source string checks'
grep -n 'RNuptake + r.RNfixation' venv_designb/lib/python3.10/site-packages/pcse/crop/nutrients/n_demand_uptake.py
grep -n 'NfixTotal' venv_designb/lib/python3.10/site-packages/pcse/conf/Wofost81_NWLP_CWB_CNB.conf
echo '[7] python import checks'
source venv_designb/bin/activate
python - <<'PY'
import pcse, inspect
import pcse.crop.nutrients.n_demand_uptake as ndu
import pcse.crop.n_dynamics as nd
print('pcse_version', getattr(pcse, '__version__', 'unknown'))
print('pcse_file', pcse.__file__)
print('n_demand_uptake_file', inspect.getfile(ndu))
print('n_dynamics_file', inspect.getfile(nd))
PY
echo "PATCH_LOG=$log"
