#!/usr/bin/env python3
"""APSIM CO2 runner regression check.

Runs 3 baseline scenarios x P000/P009/P010 x APSIM only = 9 profiles.
It verifies the Full Simulation runner rule: CO2 comes from the locked
perturbation matrix and is written to APSIM .met files.
"""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import sqlite3
import subprocess
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1] / "APSIM_CO2_Runner_Regression_Check"
DESIGN_B = Path(__file__).resolve().parents[1] / "inputs"
BASELINE_CSV = DESIGN_B / "Baseline_Scenarios" / "scenario_matrix.csv"
PERT_CSV = DESIGN_B / "Perturbation_Matrix" / "perturbation_matrix.csv"
BASE_APSIM_DIR = DESIGN_B / "Baseline_Scenarios" / "apsim"
WEATHER_DIR = DESIGN_B / "Weather_Library" / "apsim_met"
MODELS = Path(__import__("os").environ.get("APSIM_CLI", "Models"))

MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]
BASELINE_IDS = ["B0001", "B0002", "B0003"]
PERTURBATION_IDS = ["P000", "P009", "P010"]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def walk_nodes(node: Any):
    if isinstance(node, dict):
        yield node
        for child in node.get("Children", []) or []:
            yield from walk_nodes(child)
    elif isinstance(node, list):
        for item in node:
            yield from walk_nodes(item)


def set_param(node: dict[str, Any], key: str, value: str) -> bool:
    for child in node.get("Parameters", []) or []:
        if child.get("Key") == key:
            child["Value"] = value
            return True
    return False


def apsim_date(d: date) -> str:
    return f"{d.day}-{MONTHS[d.month - 1]}"


def date_from_doy(year: int, doy: int) -> date:
    return date(year, 1, 1) + timedelta(days=doy - 1)


def read_csv_dict(path: Path) -> list[dict[str, str]]:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def add_constant_co2_to_met(src: Path, dst: Path, co2_ppm: float) -> dict[str, Any]:
    lines = src.read_text().splitlines()
    out: list[str] = []
    header_seen = False
    unit_pending = False
    data_rows = 0
    co2_col_index = None
    for line in lines:
        parts = line.split()
        if len(parts) >= 6 and parts[0:2] == ["year", "day"] and "radn" in parts and "rain" in parts:
            lower = [p.lower() for p in parts]
            if "co2" in lower:
                co2_col_index = lower.index("co2")
                out.append(line)
            else:
                co2_col_index = len(parts)
                out.append(line + " co2")
                unit_pending = True
            header_seen = True
            continue
        if unit_pending:
            out.append(line + " (ppm)")
            unit_pending = False
            continue
        if header_seen and len(parts) >= 6:
            try:
                int(parts[0])
                int(parts[1])
                new_parts = list(parts)
                if co2_col_index is not None and co2_col_index < len(new_parts):
                    new_parts[co2_col_index] = f"{co2_ppm:.1f}"
                    out.append(" ".join(new_parts))
                else:
                    out.append(line + f" {co2_ppm:.1f}")
                data_rows += 1
                continue
            except Exception:
                pass
        out.append(line)
    if data_rows == 0:
        raise RuntimeError(f"No APSIM weather data rows modified in {src}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text("\n".join(out) + "\n")
    return {
        "source_met": str(src),
        "output_met": str(dst),
        "source_hash": sha256_file(src),
        "output_hash": sha256_file(dst),
        "co2_ppm": co2_ppm,
        "data_rows_with_co2": data_rows,
    }


def edit_apsimx(src: Path, dst: Path, met: Path, sowing: date, n_amount: float) -> dict[str, Any]:
    data = json.loads(src.read_text())
    found_weather = found_sowing = found_fert = found_report = False
    for node in walk_nodes(data):
        name = node.get("Name")
        if name == "Weather" and "FileName" in node:
            node["FileName"] = str(met)
            found_weather = True
        elif name == "Sow using a variable rule":
            sow_str = apsim_date(sowing)
            found_sowing = set_param(node, "StartDate", sow_str) and set_param(node, "EndDate", sow_str)
        elif name == "Fertilise at sowing":
            found_fert = set_param(node, "Amount", f"{n_amount:g}")
        elif name == "Report" and "VariableNames" in node:
            if "[Weather].CO2" not in node["VariableNames"]:
                node["VariableNames"].append("[Weather].CO2")
            found_report = True
    if not (found_weather and found_sowing and found_fert and found_report):
        raise RuntimeError(f"APSIM edit failed: weather={found_weather}, sowing={found_sowing}, fert={found_fert}, report={found_report}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    text = dst.read_text(errors="ignore")
    return {
        "apsimx": str(dst),
        "apsimx_hash": sha256_file(dst),
        "contains_weather_co2_report": "[Weather].CO2" in text,
        "contains_literal_CO2": "CO2" in text,
    }


def float_or_none(value: Any) -> float | None:
    try:
        if value in ("", None):
            return None
        return float(value)
    except Exception:
        return None


def derive_endpoint(daily_csv: Path) -> dict[str, Any]:
    rows = read_csv_dict(daily_csv)
    def colmax(name: str) -> float | None:
        return max([x for x in (float_or_none(r.get(name)) for r in rows) if x is not None], default=None)
    flowering = None
    maturity = None
    for r in rows:
        try:
            d = datetime.strptime(r.get("Clock.Today", "").split()[0], "%Y-%m-%d").date()
        except Exception:
            continue
        stage = r.get("Soybean.Phenology.CurrentStageName", "")
        if flowering is None and stage == "StartFlowering":
            flowering = d.timetuple().tm_yday
        if maturity is None and stage == "Maturity":
            maturity = d.timetuple().tm_yday
    grain = colmax("Soybean.Grain.Wt")
    biomass = colmax("Soybean.AboveGround.Wt")
    hi = grain / biomass if grain is not None and biomass not in (None, 0) else None
    co2_vals = sorted({float_or_none(r.get("Weather.CO2")) for r in rows if float_or_none(r.get("Weather.CO2")) is not None})
    return {
        "yield": grain,
        "max_lai": colmax("Soybean.LAI"),
        "max_biomass": biomass,
        "flowering_doy": flowering,
        "maturity_doy": maturity,
        "harvest_index": hi,
        "reported_co2_values": "|".join(f"{v:g}" for v in co2_vals),
        "reported_co2_unique_count": len(co2_vals),
    }


def build_profiles() -> list[dict[str, Any]]:
    baselines = {r["scenario_id"]: r for r in read_csv_dict(BASELINE_CSV)}
    perturbations = {r["perturbation_id"]: r for r in read_csv_dict(PERT_CSV)}
    profiles: list[dict[str, Any]] = []
    for sid in BASELINE_IDS:
        sc = baselines[sid]
        for pid in PERTURBATION_IDS:
            pt = perturbations[pid]
            year = int(float(sc["weather_year"]))
            sow_doy = int(float(sc["sowing_doy"]))
            delta = int(float(pt["sowing_date_delta_days"]))
            adjusted = date_from_doy(year, sow_doy + delta)
            profiles.append({
                "profile_id": f"A_{sid}_{pid}",
                "scenario_id": sid,
                "perturbation_id": pid,
                "weather_year": year,
                "original_sowing_doy": sow_doy,
                "adjusted_sowing_doy": adjusted.timetuple().tm_yday,
                "adjusted_sowing_date": adjusted.isoformat(),
                "n_rate_kg_ha": float(sc["n_rate_kg_ha"]),
                "nitrogen_availability_multiplier": float(pt["nitrogen_availability_multiplier"]),
                "co2_ppm": float(pt["co2_ppm"]),
                "label": pt["level"] if pid != "P000" else "anchor",
            })
    return profiles


def run_profile(profile: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    pid = profile["profile_id"]
    sid = profile["scenario_id"]
    year = int(profile["weather_year"])
    met = ROOT / "inputs" / f"{pid}.met"
    apsimx = ROOT / "work" / pid / f"{pid}.apsimx"
    daily = ROOT / "outputs" / "daily" / f"{pid}.csv"
    endpoint_path = ROOT / "outputs" / "endpoints" / f"{pid}.json"
    stdout_log = ROOT / "logs" / f"{pid}.stdout.log"
    stderr_log = ROOT / "logs" / f"{pid}.stderr.log"
    base_met = WEATHER_DIR / f"{year}.met"
    base_apsimx = BASE_APSIM_DIR / sid / f"{sid}.apsimx"
    n_amount = float(profile["n_rate_kg_ha"]) * float(profile["nitrogen_availability_multiplier"])
    weather_audit = add_constant_co2_to_met(base_met, met, profile["co2_ppm"])
    apsimx_audit = edit_apsimx(base_apsimx, apsimx, met, date.fromisoformat(profile["adjusted_sowing_date"]), n_amount)
    t0 = time.time()
    proc = subprocess.run([str(MODELS), str(apsimx)], cwd=str(apsimx.parent), capture_output=True, text=True, timeout=180)
    runtime = time.time() - t0
    stdout_log.parent.mkdir(parents=True, exist_ok=True)
    stderr_log.parent.mkdir(parents=True, exist_ok=True)
    stdout_log.write_text(proc.stdout)
    stderr_log.write_text(proc.stderr)
    result = {
        **profile,
        "runtime_s": round(runtime, 6),
        "status": "unknown",
        "error": "",
        "daily_csv": str(daily),
        "endpoint_json": str(endpoint_path),
    }
    if proc.returncode != 0:
        result.update({"status": "error", "error": (proc.stderr or proc.stdout)[-2000:]})
        return result, {**weather_audit, **apsimx_audit}
    dbs = list(apsimx.parent.glob("*.db"))
    if not dbs:
        result.update({"status": "no_db", "error": "No APSIM db produced"})
        return result, {**weather_audit, **apsimx_audit}
    con = sqlite3.connect(str(dbs[0]))
    cols = [r[1] for r in con.execute("PRAGMA table_info(Report)").fetchall()]
    data = con.execute('SELECT * FROM Report ORDER BY "Clock.Today"').fetchall()
    con.close()
    daily.parent.mkdir(parents=True, exist_ok=True)
    with open(daily, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        w.writerows(data)
    endpoint = derive_endpoint(daily)
    endpoint_path.parent.mkdir(parents=True, exist_ok=True)
    endpoint_path.write_text(json.dumps(endpoint, indent=2))
    result.update({
        "status": "ok",
        "daily_hash": sha256_file(daily),
        "endpoint_hash": sha256_file(endpoint_path),
        **endpoint,
    })
    return result, {**profile, **weather_audit, **apsimx_audit}


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    results = []
    audits = []
    profiles = build_profiles()
    if len(profiles) != 9:
        raise RuntimeError(f"Expected 9 regression profiles, got {len(profiles)}")
    for profile in profiles:
        result, audit = run_profile(profile)
        results.append(result)
        audits.append(audit)
    write_csv(ROOT / "qa" / "apsim_co2_smoke_results.csv", results)
    write_csv(ROOT / "qa" / "apsim_co2_input_audit.csv", audits)
    comparisons = []
    by = {(r["scenario_id"], r["perturbation_id"]): r for r in results}
    for sid in BASELINE_IDS:
        anchor = by[(sid, "P000")]
        for pid in ["P009", "P010"]:
            r = by[(sid, pid)]
            comparisons.append({
                "scenario_id": sid,
                "perturbation_id": pid,
                "comparison": f"{sid}_{pid}_vs_P000",
                "daily_hash_identical": r.get("daily_hash") == anchor.get("daily_hash"),
                "reported_co2": r.get("reported_co2_values"),
                "anchor_reported_co2": anchor.get("reported_co2_values"),
                "yield_delta": (r.get("yield") or 0) - (anchor.get("yield") or 0),
                "biomass_delta": (r.get("max_biomass") or 0) - (anchor.get("max_biomass") or 0),
                "lai_delta": (r.get("max_lai") or 0) - (anchor.get("max_lai") or 0),
                "flowering_delta": (r.get("flowering_doy") or 0) - (anchor.get("flowering_doy") or 0),
                "maturity_delta": (r.get("maturity_doy") or 0) - (anchor.get("maturity_doy") or 0),
            })
    write_csv(ROOT / "qa" / "apsim_co2_smoke_comparisons.csv", comparisons)
    manifest = []
    for folder in ["inputs", "work", "outputs", "logs", "qa", "scripts"]:
        for path in (ROOT / folder).rglob("*"):
            if path.is_file():
                manifest.append({"path": str(path), "size_bytes": path.stat().st_size, "sha256": sha256_file(path)})
    write_csv(ROOT / "manifests" / "apsim_co2_smoke_sha256_manifest.csv", manifest)
    passed = (
        len(results) == 9
        and all(r.get("status") == "ok" for r in results)
        and all(a.get("contains_weather_co2_report") is True for a in audits)
        and all(str(r.get("reported_co2_values")) == f"{float(r['co2_ppm']):g}" for r in results)
        and all(c.get("daily_hash_identical") is False for c in comparisons)
    )
    report = [
        "# APSIM CO2 Runner Regression Check",
        "",
        f"Regression status: {'PASS' if passed else 'FAIL'}",
        "",
        "Design: 3 baseline scenarios x P000/P009/P010 x APSIM only = 9 profiles.",
        "",
        "Key QA:",
        f"- result rows: {len(results)}",
        f"- all ok: {all(r.get('status') == 'ok' for r in results)}",
        f"- all generated apsimx contain [Weather].CO2: {all(a.get('contains_weather_co2_report') is True for a in audits)}",
        f"- all P009/P010 non-identical to anchor: {all(c.get('daily_hash_identical') is False for c in comparisons)}",
        "",
        "Files:",
        "- `qa/apsim_co2_smoke_results.csv`",
        "- `qa/apsim_co2_input_audit.csv`",
        "- `qa/apsim_co2_smoke_comparisons.csv`",
    ]
    report_path = ROOT / "reports" / "APSIM_CO2_RUNNER_REGRESSION_REPORT.md"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(report))
    print(json.dumps({"passed": passed, "results": results, "comparisons": comparisons}, indent=2))
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
