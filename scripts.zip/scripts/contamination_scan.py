#!/usr/bin/env python3
from pathlib import Path
import csv
root = Path(__file__).resolve().parents[1]
tokens = ['B2覆写apsim','semantic transfer','hybrid APSIM','old Sobol','old SHAP','old classifier','wofost_crop_harmonized.crop']
out = root / 'qa' / 'manual_contamination_scan.csv'
hits = []
for base in ['inputs','outputs','qa','manifests','work']:
    for p in (root / base).rglob('*'):
        if p == out:
            continue
        if not p.is_file() or p.stat().st_size > 2_000_000:
            continue
        try:
            text = p.read_text(errors='ignore')
        except Exception:
            continue
        for token in tokens:
            if token in text:
                hits.append({'file': str(p), 'token': token})
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['file','token']); w.writeheader(); w.writerows(hits)
print(f'hits={len(hits)} file={out}')
