#!/usr/bin/env python3
"""Codex Pilot A runner.

Purpose: verify that Design B perturbations actually enter APSIM and WOFOST.
This script runs an isolated 5 x 30 x 2 operational pilot under
/Users/mengchang/Desktop/Codex_Pilot_B_Rerun_v2.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import shutil
import sqlite3
import subprocess
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any


PILOT = Path(__file__).resolve().parents[1]
DESIGN_B = PILOT / "inputs"
VENV = Path(sys.executable)
MODELS = Path(os.environ.get("APSIM_CLI", "Models"))

BASELINE_CSV = DESIGN_B / "Baseline_Scenarios" / "scenario_matrix.csv"
PERT_CSV = DESIGN_B / "Perturbation_Matrix" / "perturbation_matrix.csv"
SOURCE_APSIM = DESIGN_B / "Baseline_Scenarios" / "apsim"
SOURCE_WOFOST = DESIGN_B / "Baseline_Scenarios" / "wofost"
SOURCE_WOFOST_REPO = PILOT / "wofost_runtime" / "materialized_cached_wofost81_repo"
SOURCE_WOFOST_SOIL = PILOT / "wofost_runtime" / "wofost_soil_ames_clarion.soil"

YEARS = {2000, 2009, 2015, 2018, 2024}
PERT_SELECTION = {
    "anchor": ("perturbation_family", "anchor"),
    "radiation": ("factor_changed", "radiation_multiplier"),
    "temperature": ("factor_changed", "temperature_delta_c"),
    "water": ("factor_changed", "water_availability_multiplier"),
    "sowing": ("factor_changed", "sowing_date_delta_days"),
}

MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]

DIRS = {
    "inputs": PILOT / "inputs",
    "scripts": PILOT / "scripts",
    "logs": PILOT / "logs",
    "qa": PILOT / "qa",
    "manifests": PILOT / "manifests",
    "reports": PILOT / "reports",
    "work": PILOT / "work",
    "apsim_daily": PILOT / "outputs" / "apsim" / "daily",
    "apsim_endpoints": PILOT / "outputs" / "apsim" / "endpoints",
    "wofost_daily": PILOT / "outputs" / "wofost" / "daily",
    "wofost_endpoints": PILOT / "outputs" / "wofost" / "endpoints",
}

for _d in DIRS.values():
    _d.mkdir(parents=True, exist_ok=True)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_csv_dict(path: Path) -> list[dict[str, str]]:
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def write_csv_dict(path: Path, rows: list[dict[str, Any]], fieldnames: list[str] | None = None) -> None:
    if fieldnames is None:
        keys: list[str] = []
        for row in rows:
            for key in row:
                if key not in keys:
                    keys.append(key)
        fieldnames = keys
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def date_from_doy(year: int, doy: int) -> date:
    return date(year, 1, 1) + timedelta(days=doy - 1)


def apsim_date(d: date) -> str:
    return f"{d.day}-{MONTHS[d.month - 1]}"


def iso_date(value: Any) -> str:
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return str(value)


def float_or_none(value: Any) -> float | None:
    try:
        if value in ("", None):
            return None
        x = float(value)
        if math.isnan(x):
            return None
        return x
    except Exception:
        return None


def select_inputs() -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    scenarios = [r for r in read_csv_dict(BASELINE_CSV) if int(float(r["weather_year"])) in YEARS]
    scenarios = sorted(scenarios, key=lambda r: int(r["scenario_index"]))
    if len(scenarios) != 30:
        raise RuntimeError(f"Expected 30 scenarios, found {len(scenarios)}")

    all_pt = read_csv_dict(PERT_CSV)
    selected: list[dict[str, str]] = []

    anchor = [r for r in all_pt if r["perturbation_family"] == "anchor"]
    if len(anchor) != 1:
        raise RuntimeError(f"Expected one anchor perturbation, found {len(anchor)}")
    selected.append(anchor[0])

    for _, (field, value) in list(PERT_SELECTION.items())[1:]:
        matches = [r for r in all_pt if r[field] == value and r["level"] == "low"]
        if len(matches) != 1:
            raise RuntimeError(f"Expected one low perturbation for {value}, found {len(matches)}")
        selected.append(matches[0])

    ids = [r["perturbation_id"] for r in selected]
    if len(set(ids)) != 5:
        raise RuntimeError(f"Perturbation selection is not unique: {ids}")
    return scenarios, selected


def copy_inputs(scenarios: list[dict[str, str]], perturbations: list[dict[str, str]]) -> dict[str, Path]:
    inputs = DIRS["inputs"]
    (inputs / "matrices").mkdir(parents=True, exist_ok=True)
    shutil.copy2(BASELINE_CSV, inputs / "matrices" / "scenario_matrix_source.csv")
    shutil.copy2(PERT_CSV, inputs / "matrices" / "perturbation_matrix_source.csv")
    write_csv_dict(inputs / "matrices" / "selected_baselines.csv", scenarios)
    write_csv_dict(inputs / "matrices" / "selected_perturbations.csv", perturbations)

    apsim_base = inputs / "apsim_baselines"
    wofost_base = inputs / "wofost_baselines"
    weather_apsim = inputs / "weather" / "apsim_met" / "original"
    weather_pcse = inputs / "weather" / "pcse_csv" / "original"
    for d in [apsim_base, wofost_base, weather_apsim, weather_pcse]:
        d.mkdir(parents=True, exist_ok=True)

    copied_years: set[int] = set()
    for sc in scenarios:
        sid = sc["scenario_id"]
        year = int(float(sc["weather_year"]))
        src_a = SOURCE_APSIM / sid / f"{sid}.apsimx"
        dst_a_dir = apsim_base / sid
        dst_a_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_a, dst_a_dir / f"{sid}.apsimx")

        src_w_dir = SOURCE_WOFOST / sid
        dst_w_dir = wofost_base / sid
        if dst_w_dir.exists():
            shutil.rmtree(dst_w_dir)
        shutil.copytree(src_w_dir, dst_w_dir)

        if year not in copied_years:
            src_apsim_weather = Path(sc.get("apsim_weather_file", ""))
            if not src_apsim_weather.exists():
                src_apsim_weather = DESIGN_B / "Weather_Library" / "apsim_met" / f"{year}.met"
            src_wofost_weather = Path(sc.get("wofost_weather_file", ""))
            if not src_wofost_weather.exists():
                src_wofost_weather = DESIGN_B / "Weather_Library" / "pcse_csv" / f"{year}_pcse_weather.csv"
            shutil.copy2(src_apsim_weather, weather_apsim / f"{year}.met")
            shutil.copy2(src_wofost_weather, weather_pcse / f"{year}_pcse_weather.csv")
            copied_years.add(year)

    wofost_inputs = inputs / "wofost_runtime"
    wofost_inputs.mkdir(parents=True, exist_ok=True)
    repo_dst = wofost_inputs / "materialized_cached_wofost81_repo"
    if repo_dst.exists():
        shutil.rmtree(repo_dst)
    shutil.copytree(SOURCE_WOFOST_REPO, repo_dst)
    shutil.copy2(SOURCE_WOFOST_SOIL, wofost_inputs / "wofost_soil_ames_clarion.soil")

    return {
        "apsim_base": apsim_base,
        "wofost_base": wofost_base,
        "apsim_weather": weather_apsim,
        "pcse_weather": weather_pcse,
        "wofost_repo": repo_dst,
        "wofost_soil": wofost_inputs / "wofost_soil_ames_clarion.soil",
    }


def summarize_apsim_met(path: Path) -> dict[str, float]:
    radn = []
    tmean = []
    rain = []
    in_data = False
    with open(path) as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 6 and parts[0].lower() == "year" and parts[1].lower() == "day":
                in_data = True
                continue
            if not in_data or len(parts) < 6:
                continue
            try:
                radn.append(float(parts[2]))
                tmean.append((float(parts[3]) + float(parts[4])) / 2)
                rain.append(float(parts[5]))
            except Exception:
                continue
    return {
        "rad_sum": round(sum(radn), 6),
        "tmean_mean": round(sum(tmean) / len(tmean), 6) if tmean else None,
        "rain_sum": round(sum(rain), 6),
    }


def perturb_apsim_met(
    src: Path,
    dst: Path,
    rad_mult: float,
    temp_delta: float,
    water_mult: float,
    co2_ppm: float = 420.0,
) -> dict[str, Any]:
    lines = src.read_text().splitlines(True)
    out_lines: list[str] = []
    in_data = False
    header_parts: list[str] | None = None
    unit_line_pending = False
    for line in lines:
        stripped = line.strip()
        parts = stripped.split()
        if stripped.lower().startswith("tav ="):
            try:
                current = float(stripped.split("=")[1].strip())
                out_lines.append(f"tav = {current + temp_delta:.2f}\n")
                continue
            except Exception:
                pass
        if len(parts) >= 6 and parts[0].lower() == "year" and parts[1].lower() == "day":
            in_data = True
            header_parts = list(parts)
            if not any(p.lower() == "co2" for p in header_parts):
                header_parts.append("co2")
            out_lines.append(" ".join(header_parts) + "\n")
            unit_line_pending = True
            continue
        if unit_line_pending:
            unit_parts = list(parts)
            if header_parts and len(unit_parts) < len(header_parts):
                unit_parts.append("(ppm)")
                out_lines.append(" ".join(unit_parts) + "\n")
            else:
                out_lines.append(line)
            unit_line_pending = False
            continue
        if in_data and len(parts) >= 6:
            try:
                year, day = parts[0], parts[1]
                radn = float(parts[2]) * rad_mult
                maxt = float(parts[3]) + temp_delta
                mint = float(parts[4]) + temp_delta
                rain = float(parts[5]) * water_mult
                out_lines.append(f"{year} {day} {radn:.2f} {maxt:.2f} {mint:.2f} {rain:.2f} {float(co2_ppm):.1f}\n")
                continue
            except Exception:
                pass
        out_lines.append(line)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text("".join(out_lines))
    before = summarize_apsim_met(src)
    after = summarize_apsim_met(dst)
    return {
        "source_hash": sha256_file(src),
        "output_hash": sha256_file(dst),
        "output_has_co2": bool(header_parts and any(p.lower() == "co2" for p in header_parts)),
        "output_co2_values": ",".join(map(str, sorted(read_apsim_met_co2_values(dst)))),
        "source_rad_sum": before["rad_sum"],
        "output_rad_sum": after["rad_sum"],
        "source_tmean_mean": before["tmean_mean"],
        "output_tmean_mean": after["tmean_mean"],
        "source_rain_sum": before["rain_sum"],
        "output_rain_sum": after["rain_sum"],
    }


def read_apsim_met_co2_values(path: Path) -> set[float]:
    header: list[str] | None = None
    values: set[float] = set()
    with open(path) as f:
        for line in f:
            parts = line.split()
            if len(parts) >= 6 and parts[0].lower() == "year" and parts[1].lower() == "day":
                header = parts
                continue
            if header is None or len(parts) < len(header):
                continue
            try:
                idx = [p.lower() for p in header].index("co2")
            except ValueError:
                continue
            try:
                values.add(round(float(parts[idx]), 6))
            except Exception:
                continue
    return values


def read_pcse_weather(path: Path) -> tuple[list[str], list[str], list[dict[str, str]]]:
    lines = path.read_text().splitlines()
    header_idx = None
    for i, line in enumerate(lines):
        if line.startswith("DAY,"):
            header_idx = i
            break
    if header_idx is None:
        raise RuntimeError(f"PCSE weather header not found: {path}")
    metadata = lines[:header_idx]
    header = lines[header_idx].split(",")
    required = {"DAY", "IRRAD", "TMIN", "TMAX", "VAP", "WIND", "RAIN", "SNOWDEPTH"}
    missing = required - set(header)
    if missing:
        raise RuntimeError(f"PCSE weather missing columns {sorted(missing)}: {path}")
    rows = list(csv.DictReader(lines[header_idx + 1 :], fieldnames=header))
    return metadata, header, rows


def summarize_pcse_rows(rows: list[dict[str, str]]) -> dict[str, float]:
    irrad = []
    tmean = []
    rain = []
    for row in rows:
        irrad.append(float(row["IRRAD"]))
        tmean.append((float(row["TMIN"]) + float(row["TMAX"])) / 2)
        rain.append(float(row["RAIN"]))
    return {
        "irrad_sum": round(sum(irrad), 6),
        "tmean_mean": round(sum(tmean) / len(tmean), 6) if tmean else None,
        "rain_sum": round(sum(rain), 6),
    }


def fmt_float(value: float, decimals: int = 2) -> str:
    return f"{value:.{decimals}f}"


def perturb_pcse_weather(src: Path, dst: Path, rad_mult: float, temp_delta: float, water_mult: float) -> dict[str, Any]:
    metadata, header, rows = read_pcse_weather(src)
    before = summarize_pcse_rows(rows)
    out_rows: list[dict[str, str]] = []
    for row in rows:
        new = dict(row)
        new["IRRAD"] = fmt_float(float(row["IRRAD"]) * rad_mult, 2)
        new["TMIN"] = fmt_float(float(row["TMIN"]) + temp_delta, 2)
        new["TMAX"] = fmt_float(float(row["TMAX"]) + temp_delta, 2)
        new["RAIN"] = fmt_float(float(row["RAIN"]) * water_mult, 2)
        out_rows.append(new)
    dst.parent.mkdir(parents=True, exist_ok=True)
    with open(dst, "w", newline="") as f:
        for line in metadata:
            f.write(line + "\n")
        w = csv.DictWriter(f, fieldnames=header, lineterminator="\n")
        w.writeheader()
        w.writerows(out_rows)
    _, _, check_rows = read_pcse_weather(dst)
    after = summarize_pcse_rows(check_rows)
    return {
        "source_hash": sha256_file(src),
        "output_hash": sha256_file(dst),
        "source_irrad_sum": before["irrad_sum"],
        "output_irrad_sum": after["irrad_sum"],
        "source_tmean_mean": before["tmean_mean"],
        "output_tmean_mean": after["tmean_mean"],
        "source_rain_sum": before["rain_sum"],
        "output_rain_sum": after["rain_sum"],
    }


def walk_nodes(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for value in obj.values():
            yield from walk_nodes(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from walk_nodes(value)


def set_param(node: dict[str, Any], key: str, value: str) -> bool:
    for param in node.get("Parameters", []):
        if param.get("Key") == key:
            param["Value"] = value
            return True
    return False


def get_param(node: dict[str, Any], key: str) -> str | None:
    for param in node.get("Parameters", []):
        if param.get("Key") == key:
            return str(param.get("Value"))
    return None


def edit_apsimx_structured(src: Path, dst: Path, weather_path: Path, sowing: date, n_amount: float) -> dict[str, Any]:
    data = json.load(open(src))
    found_weather = found_sowing = found_fert = found_report = False
    for node in walk_nodes(data):
        name = node.get("Name")
        if name == "Weather" and "FileName" in node:
            node["FileName"] = str(weather_path)
            found_weather = True
        elif name == "Sow using a variable rule":
            sow_str = apsim_date(sowing)
            found_sowing = set_param(node, "StartDate", sow_str) and set_param(node, "EndDate", sow_str)
        elif name == "Fertilise at sowing":
            found_fert = set_param(node, "Amount", f"{n_amount:g}")
        elif name == "Report" and "VariableNames" in node:
            if "[Weather].CO2" not in node["VariableNames"]:
                node["VariableNames"].append("[Weather].CO2")
            found_report = True
    if not (found_weather and found_sowing and found_fert and found_report):
        raise RuntimeError(
            f"APSIM edit failed: weather={found_weather}, sowing={found_sowing}, "
            f"fert={found_fert}, report={found_report}, file={src}"
        )
    dst.parent.mkdir(parents=True, exist_ok=True)
    json.dump(data, open(dst, "w"), indent=2, ensure_ascii=False)

    actual = {"weather_file": None, "start_date": None, "end_date": None, "n_amount": None, "report_has_weather_co2": False}
    check = json.load(open(dst))
    for node in walk_nodes(check):
        name = node.get("Name")
        if name == "Weather" and "FileName" in node:
            actual["weather_file"] = node["FileName"]
        elif name == "Sow using a variable rule":
            actual["start_date"] = get_param(node, "StartDate")
            actual["end_date"] = get_param(node, "EndDate")
        elif name == "Fertilise at sowing":
            actual["n_amount"] = get_param(node, "Amount")
        elif name == "Report" and "VariableNames" in node:
            actual["report_has_weather_co2"] = "[Weather].CO2" in node["VariableNames"]
    return actual


def run_apsim(profile: dict[str, Any], paths: dict[str, Path]) -> dict[str, Any]:
    pid = profile["profile_id"]
    sid = profile["scenario_id"]
    year = int(profile["weather_year"])
    rad_mult = float(profile["radiation_multiplier"])
    temp_delta = float(profile["temperature_delta_c"])
    water_mult = float(profile["water_availability_multiplier"])
    n_mult = float(profile["nitrogen_availability_multiplier"])
    sow_delta = int(float(profile["sowing_date_delta_days"]))
    n_amount = float(profile["n_rate_kg_ha"]) * n_mult
    adjusted_sowing = date_from_doy(year, int(profile["sowing_doy"]) + sow_delta)

    src_met = paths["apsim_weather"] / f"{year}.met"
    pert_met = DIRS["inputs"] / "weather" / "apsim_met" / "perturbed" / f"{sid}_{profile['perturbation_id']}.met"
    expected_co2 = float(profile["co2_ppm"])
    weather_qa = perturb_apsim_met(src_met, pert_met, rad_mult, temp_delta, water_mult, expected_co2)

    base_apsimx = paths["apsim_base"] / sid / f"{sid}.apsimx"
    work_dir = DIRS["work"] / "apsim" / pid
    if work_dir.exists():
        shutil.rmtree(work_dir)
    work_dir.mkdir(parents=True)
    apsimx = work_dir / f"{pid}.apsimx"
    actual = edit_apsimx_structured(base_apsimx, apsimx, pert_met, adjusted_sowing, n_amount)

    input_qa = {
        **profile,
        "model": "APSIM",
        "weather_file": actual["weather_file"],
        "expected_weather_file": str(pert_met),
        "actual_sowing_date": actual["start_date"],
        "expected_sowing_date": apsim_date(adjusted_sowing),
        "actual_n_amount": actual["n_amount"],
        "expected_n_amount": f"{n_amount:g}",
        "actual_report_has_weather_co2": actual["report_has_weather_co2"],
        "expected_co2_ppm": f"{expected_co2:.1f}",
        "apsimx_hash": sha256_file(apsimx),
        "weather_source_hash": weather_qa["source_hash"],
        "weather_output_hash": weather_qa["output_hash"],
        **{f"weather_{k}": v for k, v in weather_qa.items() if k not in ("source_hash", "output_hash")},
    }

    daily_out = DIRS["apsim_daily"] / f"{pid}.csv"
    endpoint_out = DIRS["apsim_endpoints"] / f"{pid}.json"
    log_out = DIRS["logs"] / f"{pid}.stdout.log"
    log_err = DIRS["logs"] / f"{pid}.stderr.log"
    t0 = time.time()
    result = subprocess.run([str(MODELS), str(apsimx)], cwd=str(work_dir), capture_output=True, text=True, timeout=180)
    runtime = time.time() - t0
    log_out.write_text(result.stdout)
    log_err.write_text(result.stderr)

    row = {**profile, "model": "APSIM", "runtime_s": round(runtime, 6), "status": "unknown", "error": ""}
    dbs = list(work_dir.glob("*.db"))
    if result.returncode != 0:
        row.update({"status": "error", "error": result.stderr[-1000:]})
        return row, input_qa
    if not dbs:
        row.update({"status": "no_db", "error": "APSIM did not produce a database"})
        return row, input_qa
    db = sqlite3.connect(str(dbs[0]))
    tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    if "Report" not in tables:
        db.close()
        row.update({"status": "no_report", "error": "APSIM database lacks Report table"})
        return row, input_qa
    cols = [r[1] for r in db.execute("PRAGMA table_info(Report)").fetchall()]
    data = db.execute('SELECT * FROM Report ORDER BY "Clock.Today"').fetchall()
    db.close()
    with open(daily_out, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        w.writerows(data)
    endpoint = derive_apsim_endpoint(daily_out, pid, profile)
    endpoint["runtime_s"] = round(runtime, 6)
    endpoint["daily_csv"] = str(daily_out)
    json.dump(endpoint, open(endpoint_out, "w"), indent=2)
    row.update({
        "status": "ok",
        "daily_csv": str(daily_out),
        "endpoint_json": str(endpoint_out),
        "daily_hash": sha256_file(daily_out),
        "endpoint_hash": sha256_file(endpoint_out),
        **endpoint,
    })
    return row, input_qa


def derive_apsim_endpoint(daily_csv: Path, pid: str, profile: dict[str, Any]) -> dict[str, Any]:
    rows = read_csv_dict(daily_csv)
    lai_vals = [float_or_none(r.get("Soybean.LAI")) for r in rows]
    biomass_vals = [float_or_none(r.get("Soybean.AboveGround.Wt")) for r in rows]
    grain_vals = [float_or_none(r.get("Soybean.Grain.Wt")) for r in rows]
    lai = max([x for x in lai_vals if x is not None], default=None)
    biomass = max([x for x in biomass_vals if x is not None], default=None)
    grain = max([x for x in grain_vals if x is not None], default=None)

    flowering = None
    maturity = None
    for r in rows:
        today = r.get("Clock.Today", "")
        try:
            d = datetime.strptime(today.split()[0], "%Y-%m-%d").date()
            doy = d.timetuple().tm_yday
        except Exception:
            continue
        stage = r.get("Soybean.Phenology.CurrentStageName", "")
        if flowering is None and stage == "StartFlowering":
            flowering = doy
        if maturity is None and stage == "Maturity":
            maturity = doy
    hi = None
    if grain is not None and biomass and biomass != 0:
        hi = grain / biomass
    reported_co2 = sorted({
        round(float(v), 6)
        for v in (r.get("Weather.CO2") for r in rows)
        if v not in (None, "")
    })
    return {
        "profile_id": pid,
        "model": "APSIM",
        "status": "ok",
        "yield": grain,
        "max_lai": lai,
        "max_biomass": biomass,
        "flowering_doy": flowering,
        "maturity_doy": maturity,
        "harvest_index": hi,
        "cumulative_et": None,
        "cumulative_transpiration": None,
        "cumulative_n_uptake": None,
        "nfix_total": "unavailable",
        "reported_co2_values": ",".join(map(str, reported_co2)),
        "endpoint_source": "daily_series",
    }


def run_wofost(profile: dict[str, Any], paths: dict[str, Path]) -> dict[str, Any]:
    pid = profile["profile_id"]
    sid = profile["scenario_id"]
    year = int(profile["weather_year"])
    rad_mult = float(profile["radiation_multiplier"])
    temp_delta = float(profile["temperature_delta_c"])
    water_mult = float(profile["water_availability_multiplier"])
    n_mult = float(profile["nitrogen_availability_multiplier"])
    sow_delta = int(float(profile["sowing_date_delta_days"]))
    n_amount = float(profile["n_rate_kg_ha"]) * n_mult
    adjusted_sowing = date_from_doy(year, int(profile["sowing_doy"]) + sow_delta)

    src_weather = paths["pcse_weather"] / f"{year}_pcse_weather.csv"
    pert_weather = DIRS["inputs"] / "weather" / "pcse_csv" / "perturbed" / f"{sid}_{profile['perturbation_id']}_pcse_weather.csv"
    weather_qa = perturb_pcse_weather(src_weather, pert_weather, rad_mult, temp_delta, water_mult)

    daily_out = DIRS["wofost_daily"] / f"{pid}.csv"
    endpoint_out = DIRS["wofost_endpoints"] / f"{pid}.json"
    log_out = DIRS["logs"] / f"{pid}.stdout.log"
    log_err = DIRS["logs"] / f"{pid}.stderr.log"
    input_qa = {
        **profile,
        "model": "WOFOST",
        "weather_file": str(pert_weather),
        "actual_sowing_date": adjusted_sowing.isoformat(),
        "expected_sowing_date": adjusted_sowing.isoformat(),
        "actual_n_amount": f"{n_amount:g}",
        "expected_n_amount": f"{n_amount:g}",
        "weather_source_hash": weather_qa["source_hash"],
        "weather_output_hash": weather_qa["output_hash"],
        **{f"weather_{k}": v for k, v in weather_qa.items() if k not in ("source_hash", "output_hash")},
    }

    script = f"""
import csv, json, math, time
from datetime import date
from pcse.base import ParameterProvider
from pcse.input import CABOFileReader, CSVWeatherDataProvider, YAMLCropDataProvider
from pcse.input.sitedataproviders import WOFOST72SiteDataProvider
from pcse.models import Wofost81_NWLP_CWB_CNB

t0 = time.time()
cropd = YAMLCropDataProvider(Wofost81_NWLP_CWB_CNB, fpath={str(paths['wofost_repo'])!r}, force_reload=True)
cropd.set_active_crop('soybean', 'Soybean_906')
crop = dict(cropd)
for k, v in {{'TSUMEM': 90, 'TSUM1': 400, 'TSUM2': 1260, 'NFIX_FR': 0.8, 'CO2': {float(profile['co2_ppm'])}}}.items():
    crop[k] = v
soil = CABOFileReader({str(paths['wofost_soil'])!r})
for k, v in {{'NSOILBASE':20,'NSOILBASE_FR':0.02,'NAVAILI':20,'BG_N_SUPPLY':0.03,
 'N_RECOVERY_FRACTION':0.7,'KDENIT_REF':0.06,'KNIT_REF':0.08,
 'WFPS_CRIT':0.8,'KSORP':0.5,'KSUB':15,'CNRatioBio':10,
 'FGL':0,'FRNX':0.5,'NO3ConcR':1,'NH4ConcR':1,'N_demand_soil':1}}.items():
    soil[k] = v
site = WOFOST72SiteDataProvider(WAV=9.0*{water_mult})
sow = date({adjusted_sowing.year}, {adjusted_sowing.month}, {adjusted_sowing.day})
agro = [{{date({year},1,1): {{
    'CropCalendar': {{'crop_name':'soybean','variety_name':'Soybean_906',
        'crop_start_date':sow,'crop_start_type':'sowing','crop_end_date':date({year},11,15),
        'crop_end_type':'maturity','max_duration':220}},
    'TimedEvents':[{{'event_signal':'apply_n','name':'N application at sowing','comment':'Codex Pilot A',
        'events_table':[{{sow:{{'N_amount':{n_amount},'N_recovery':0.7}}}}]}}],
    'StateEvents': None
}}}}]
wdp = CSVWeatherDataProvider({str(pert_weather)!r})
params = ParameterProvider(cropdata=crop, soildata=soil, sitedata=site)
engine = Wofost81_NWLP_CWB_CNB(params, wdp, agro)
engine.run_till_terminate()
out = engine.get_output()
cols = ['day','DVS','LAI','TAGP','WSO','WLV','WST','WRT','TRA','EVS','SM','NuptakeTotal','NfixTotal','NAVAIL','Ndemand']
present = []
for c in cols:
    if c == 'day' or any(c in r for r in out):
        present.append(c)
with open({str(daily_out)!r}, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['doy'] + present)
    w.writeheader()
    for r in out:
        row = {{}}
        d = r.get('day')
        row['doy'] = d.timetuple().tm_yday if hasattr(d, 'timetuple') else ''
        for c in present:
            val = r.get(c, '')
            if hasattr(val, 'isoformat'):
                val = val.isoformat()
            row[c] = val
        w.writerow(row)
print(json.dumps({{'status':'ok','runtime_s':time.time()-t0,'rows':len(out)}}))
"""
    t0 = time.time()
    proc = subprocess.run([str(VENV), "-c", script], capture_output=True, text=True, timeout=180)
    runtime = time.time() - t0
    log_out.write_text(proc.stdout)
    log_err.write_text(proc.stderr)
    row = {**profile, "model": "WOFOST", "runtime_s": round(runtime, 6), "status": "unknown", "error": ""}
    if proc.returncode != 0 or not daily_out.exists():
        row.update({"status": "error", "error": (proc.stderr or proc.stdout)[-1500:]})
        return row, input_qa
    endpoint = derive_wofost_endpoint(daily_out, pid, profile)
    endpoint["runtime_s"] = round(runtime, 6)
    endpoint["daily_csv"] = str(daily_out)
    json.dump(endpoint, open(endpoint_out, "w"), indent=2)
    row.update({
        "status": "ok",
        "daily_csv": str(daily_out),
        "endpoint_json": str(endpoint_out),
        "daily_hash": sha256_file(daily_out),
        "endpoint_hash": sha256_file(endpoint_out),
        **endpoint,
    })
    return row, input_qa


def derive_wofost_endpoint(daily_csv: Path, pid: str, profile: dict[str, Any]) -> dict[str, Any]:
    rows = read_csv_dict(daily_csv)
    def colmax(name: str) -> float | None:
        return max([x for x in (float_or_none(r.get(name)) for r in rows) if x is not None], default=None)
    yield_v = colmax("WSO")
    biomass = colmax("TAGP")
    max_lai = colmax("LAI")
    flowering = None
    maturity = None
    for r in rows:
        dvs = float_or_none(r.get("DVS"))
        doy = float_or_none(r.get("doy"))
        if dvs is None or doy is None:
            continue
        if flowering is None and dvs >= 1.0:
            flowering = int(doy)
        if maturity is None and dvs >= 2.0:
            maturity = int(doy)
    def colsum(name: str) -> float | None:
        vals = [x for x in (float_or_none(r.get(name)) for r in rows) if x is not None]
        return sum(vals) if vals else None
    transp = colsum("TRA")
    evs = colsum("EVS")
    nuptake = colmax("NuptakeTotal")
    nfix = colmax("NfixTotal")
    hi = None
    if yield_v is not None and biomass and biomass != 0:
        hi = yield_v / biomass
    return {
        "profile_id": pid,
        "model": "WOFOST",
        "status": "ok",
        "yield": yield_v,
        "max_lai": max_lai,
        "max_biomass": biomass,
        "flowering_doy": flowering,
        "maturity_doy": maturity,
        "harvest_index": hi,
        "cumulative_et": (transp or 0) + (evs or 0) if transp is not None or evs is not None else None,
        "cumulative_transpiration": transp,
        "cumulative_n_uptake": nuptake,
        "nfix_total": nfix if nfix is not None else "unavailable",
        "endpoint_source": "daily_series",
    }


def make_profiles(scenarios: list[dict[str, str]], perturbations: list[dict[str, str]]) -> list[dict[str, Any]]:
    profiles: list[dict[str, Any]] = []
    for sc in scenarios:
        for pt in perturbations:
            year = int(float(sc["weather_year"]))
            sow_doy = int(float(sc["sowing_doy"]))
            delta = int(float(pt["sowing_date_delta_days"]))
            adjusted = date_from_doy(year, sow_doy + delta)
            base = {
                "scenario_id": sc["scenario_id"],
                "perturbation_id": pt["perturbation_id"],
                "weather_year": year,
                "original_sowing_doy": sow_doy,
                "sowing_doy": sow_doy,
                "adjusted_sowing_doy": adjusted.timetuple().tm_yday,
                "adjusted_sowing_date": adjusted.isoformat(),
                "n_rate_kg_ha": float(sc["n_rate_kg_ha"]),
                "perturbation_family": pt["perturbation_family"],
                "factor_changed": pt["factor_changed"],
                "level": pt["level"],
                "radiation_multiplier": float(pt["radiation_multiplier"]),
                "temperature_delta_c": float(pt["temperature_delta_c"]),
                "water_availability_multiplier": float(pt["water_availability_multiplier"]),
                "nitrogen_availability_multiplier": float(pt["nitrogen_availability_multiplier"]),
                "co2_ppm": float(pt["co2_ppm"]),
                "sowing_date_delta_days": float(pt["sowing_date_delta_days"]),
            }
            for model in ["APSIM", "WOFOST"]:
                prefix = "A" if model == "APSIM" else "W"
                profiles.append({**base, "model": model, "profile_id": f"{prefix}_{sc['scenario_id']}_{pt['perturbation_id']}"})
    return profiles


def run_profiles(profiles: list[dict[str, Any]], paths: dict[str, Path]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    results: list[dict[str, Any]] = []
    input_qa: list[dict[str, Any]] = []
    for i, profile in enumerate(profiles, 1):
        try:
            if profile["model"] == "APSIM":
                result, qa = run_apsim(profile, paths)
            else:
                result, qa = run_wofost(profile, paths)
        except Exception as e:
            result = {**profile, "status": "crash", "runtime_s": 0, "error": repr(e)}
            qa = {**profile, "qa_error": repr(e)}
        results.append(result)
        input_qa.append(qa)
        if i % 20 == 0 or i == len(profiles):
            ok = sum(1 for r in results if r.get("status") == "ok")
            print(f"[{i}/{len(profiles)}] ok={ok} {datetime.now().strftime('%H:%M:%S')}")
    write_csv_dict(DIRS["reports"] / "pilot_a_results.csv", results)
    write_csv_dict(DIRS["qa"] / "input_perturbation_qa.csv", input_qa)
    return results, input_qa


def compare_output_identity(results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    by_key = {(r["model"], r["scenario_id"], r["perturbation_id"]): r for r in results}
    perturb_ids = sorted({r["perturbation_id"] for r in results if r["perturbation_id"] != "P000"})
    scenario_ids = sorted({r["scenario_id"] for r in results})
    for model in ["APSIM", "WOFOST"]:
        for sid in scenario_ids:
            anchor = by_key.get((model, sid, "P000"))
            for pid in perturb_ids:
                cur = by_key.get((model, sid, pid))
                row = {"model": model, "scenario_id": sid, "perturbation_id": pid}
                if not anchor or not cur or anchor.get("status") != "ok" or cur.get("status") != "ok":
                    row.update({"comparison_status": "unavailable", "identical_to_anchor": None})
                else:
                    row.update({
                        "comparison_status": "ok",
                        "anchor_hash": anchor.get("daily_hash"),
                        "perturbation_hash": cur.get("daily_hash"),
                        "identical_to_anchor": anchor.get("daily_hash") == cur.get("daily_hash"),
                    })
                rows.append(row)
    write_csv_dict(DIRS["qa"] / "output_non_identity_qa.csv", rows)
    return rows


def evaluate_input_qa(input_qa: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for r in input_qa:
        pid = r["perturbation_id"]
        factor = r["factor_changed"]
        model = r["model"]
        if model == "APSIM":
            rad_changed = abs(float(r.get("weather_output_rad_sum", 0)) - float(r.get("weather_source_rad_sum", 0))) > 1e-6
            temp_changed = abs(float(r.get("weather_output_tmean_mean", 0)) - float(r.get("weather_source_tmean_mean", 0))) > 1e-6
            rain_changed = abs(float(r.get("weather_output_rain_sum", 0)) - float(r.get("weather_source_rain_sum", 0))) > 1e-6
        else:
            rad_changed = abs(float(r.get("weather_output_irrad_sum", 0)) - float(r.get("weather_source_irrad_sum", 0))) > 1e-6
            temp_changed = abs(float(r.get("weather_output_tmean_mean", 0)) - float(r.get("weather_source_tmean_mean", 0))) > 1e-6
            rain_changed = abs(float(r.get("weather_output_rain_sum", 0)) - float(r.get("weather_source_rain_sum", 0))) > 1e-6
        weather_changed = rad_changed or temp_changed or rain_changed
        if model == "APSIM":
            expected_sowing_change = float(r["sowing_date_delta_days"]) != 0
            actual_sowing_change = r.get("actual_sowing_date") == r.get("expected_sowing_date")
        else:
            expected_sowing_change = float(r["sowing_date_delta_days"]) != 0
            actual_sowing_change = r.get("actual_sowing_date") == r.get("expected_sowing_date")
        expected_weather_change = factor in {"radiation_multiplier", "temperature_delta_c", "water_availability_multiplier"}
        if factor == "radiation_multiplier":
            weather_pass = rad_changed and not temp_changed and not rain_changed
        elif factor == "temperature_delta_c":
            weather_pass = temp_changed and not rad_changed and not rain_changed
        elif factor == "water_availability_multiplier":
            weather_pass = rain_changed and not rad_changed and not temp_changed
        else:
            weather_pass = not weather_changed
        sowing_pass = actual_sowing_change
        n_pass = str(r.get("actual_n_amount")) == str(r.get("expected_n_amount"))
        expected_co2 = str(r.get("expected_co2_ppm", "")).strip()
        if model == "APSIM":
            co2_values = str(r.get("weather_output_co2_values", "")).split(",")
            co2_value_pass = expected_co2 in {v.strip() for v in co2_values}
            co2_pass = (
                str(r.get("weather_output_has_co2")).lower() == "true"
                and str(r.get("actual_report_has_weather_co2")).lower() == "true"
                and co2_value_pass
            )
        else:
            co2_pass = str(r.get("actual_co2_ppm", "")).strip() == expected_co2
        rows.append({
            "model": model,
            "profile_id": r["profile_id"],
            "scenario_id": r["scenario_id"],
            "perturbation_id": pid,
            "factor_changed": factor,
            "weather_changed": weather_changed,
            "rad_changed": rad_changed,
            "temp_changed": temp_changed,
            "rain_changed": rain_changed,
            "expected_weather_change": expected_weather_change,
            "weather_pass": weather_pass,
            "expected_sowing_date": r.get("expected_sowing_date"),
            "actual_sowing_date": r.get("actual_sowing_date"),
            "expected_sowing_change": expected_sowing_change,
            "sowing_pass": sowing_pass,
            "expected_n_amount": r.get("expected_n_amount"),
            "actual_n_amount": r.get("actual_n_amount"),
            "n_pass": n_pass,
            "expected_co2_ppm": expected_co2,
            "actual_co2_ppm": r.get("actual_co2_ppm"),
            "weather_output_has_co2": r.get("weather_output_has_co2"),
            "weather_output_co2_values": r.get("weather_output_co2_values"),
            "actual_report_has_weather_co2": r.get("actual_report_has_weather_co2"),
            "co2_pass": co2_pass,
        })
    write_csv_dict(DIRS["qa"] / "input_qa_pass_fail.csv", rows)
    return rows


def contamination_scan() -> list[dict[str, str]]:
    tokens = [
        "B2覆写apsim",
        "semantic transfer",
        "hybrid APSIM",
        "old Sobol",
        "old SHAP",
        "old classifier",
        "wofost_crop_harmonized.crop",
    ]
    roots = [DIRS["inputs"], DIRS["work"], DIRS["qa"], DIRS["manifests"]]
    hits = []
    for root in roots:
        for path in root.rglob("*"):
            if not path.is_file() or path.stat().st_size > 2_000_000:
                continue
            try:
                text = path.read_text(errors="ignore")
            except Exception:
                continue
            for token in tokens:
                if token in text:
                    hits.append({"file": str(path), "token": token})
    write_csv_dict(DIRS["qa"] / "contamination_scan.csv", hits, ["file", "token"])
    return hits


def write_manifest() -> None:
    rows = []
    for root in [DIRS["inputs"], DIRS["outputs"] if "outputs" in DIRS else PILOT / "outputs", DIRS["scripts"], DIRS["qa"]]:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if path.is_file():
                rows.append({"path": str(path), "sha256": sha256_file(path), "size_bytes": path.stat().st_size})
    write_csv_dict(DIRS["manifests"] / "pilot_a_sha256_manifest.csv", rows)


def field_count(rows: list[dict[str, Any]], key: str, value: Any) -> int:
    return sum(1 for r in rows if r.get(key) == value)


def generate_report(
    scenarios: list[dict[str, str]],
    perturbations: list[dict[str, str]],
    profiles: list[dict[str, Any]],
    results: list[dict[str, Any]],
    input_checks: list[dict[str, Any]],
    identity: list[dict[str, Any]],
    contamination_hits: list[dict[str, str]],
    started: datetime,
    ended: datetime,
) -> None:
    expected = 300
    ok = field_count(results, "status", "ok")
    failed = len(results) - ok
    apsim = [r for r in results if r["model"] == "APSIM"]
    wofost = [r for r in results if r["model"] == "WOFOST"]
    input_fail = [r for r in input_checks if not (r["weather_pass"] and r["sowing_pass"] and r["n_pass"])]
    identity_fail = [r for r in identity if r.get("comparison_status") == "ok" and r.get("identical_to_anchor") is True]
    failures = [r for r in results if r.get("status") != "ok"]
    endpoint_bad = [r for r in results if r.get("status") == "ok" and (float_or_none(r.get("yield")) is None or float_or_none(r.get("max_lai")) is None or float_or_none(r.get("max_biomass")) is None)]

    if input_fail or identity_fail or endpoint_bad or contamination_hits:
        final = "NO-GO"
        final_text = "Pilot A exposed critical implementation problems. Do not run Pilot B."
    elif failures:
        final = "CONDITIONAL GO"
        final_text = "Pilot A mostly successful, but weather-boundary failures must be handled before Pilot B."
    else:
        final = "GO"
        final_text = "Pilot A successful. Proceed to rerun Pilot B with corrected runner."

    failure_lines = []
    for r in failures[:40]:
        failure_lines.append(
            f"- {r['profile_id']}: year={r['weather_year']}, sow={r['original_sowing_doy']}, "
            f"adjusted={r['adjusted_sowing_doy']}, N={r['n_rate_kg_ha']}, perturb={r['perturbation_id']}, "
            f"status={r['status']}, error={str(r.get('error','')).splitlines()[0][:180]}"
        )
    if not failure_lines:
        failure_lines.append("- None.")

    pert_table = "\n".join(
        f"| {p['perturbation_id']} | {p['perturbation_family']} | {p['factor_changed']} | {p['level']} | "
        f"{p['radiation_multiplier']} | {p['temperature_delta_c']} | {p['water_availability_multiplier']} | "
        f"{p['nitrogen_availability_multiplier']} | {p['co2_ppm']} | {p['sowing_date_delta_days']} |"
        for p in perturbations
    )
    years = sorted({int(float(s["weather_year"])) for s in scenarios})
    baseline_table = "\n".join(
        f"| {y} | {sum(1 for s in scenarios if int(float(s['weather_year'])) == y)} |"
        for y in years
    )
    report = f"""# 30. Codex Pilot A Test Report

Date: {ended.isoformat(timespec='seconds')}  
Test directory: `/Users/mengchang/Desktop/Codex_Pilot_B_Rerun`  
Final recommendation: **{final}**

## 1. Executive Summary

Pilot A ran an isolated 5 x 30 x 2 test to verify that perturbations actually enter APSIM and WOFOST before rerunning Pilot B.

| Metric | Value |
|---|---:|
| Expected profiles | {expected} |
| Result rows | {len(results)} |
| Completed ok | {ok} |
| Failed / non-ok | {failed} |
| APSIM ok | {field_count(apsim, 'status', 'ok')}/{len(apsim)} |
| WOFOST ok | {field_count(wofost, 'status', 'ok')}/{len(wofost)} |
| Input QA failures | {len(input_fail)} |
| Output identity failures | {len(identity_fail)} |
| Endpoint extraction failures | {len(endpoint_bad)} |
| Contamination hits | {len(contamination_hits)} |
| Runtime wall clock | {(ended-started).total_seconds()/60:.1f} min |

Final decision: **{final_text}**

## 2. Known-error Prevention Checklist

| Prior Pilot B error | Prevention in Pilot A | Status |
|---|---|---|
| APSIM raw string replacement failed for Unicode/JSON escaped weather paths | APSIM `.apsimx` edited through parsed JSON nodes named `Weather`, `Sow using a variable rule`, and `Fertilise at sowing` | {'PASS' if not any(r for r in input_fail if r['model']=='APSIM') else 'FAIL'} |
| APSIM sowing manager was not clock start date | Manager `StartDate` and `EndDate` parameters are edited directly | {'PASS' if not any(r for r in input_fail if r['model']=='APSIM' and not r['sowing_pass']) else 'FAIL'} |
| APSIM fertilizer amount was stored as `Key`/`Value` | Manager parameter with `Key=Amount` is edited directly | {'PASS' if not any(r for r in input_fail if r['model']=='APSIM' and not r['n_pass']) else 'FAIL'} |
| WOFOST PCSE weather CSV metadata broke parsing | Metadata-aware parser finds the `DAY,IRRAD,TMIN,TMAX,VAP,WIND,RAIN,SNOWDEPTH` header | {'PASS' if not any(r for r in input_fail if r['model']=='WOFOST' and not r['weather_pass']) else 'FAIL'} |
| WOFOST used `RAD` instead of `IRRAD` | Pilot A modifies `IRRAD` | {'PASS' if not any(r for r in input_fail if r['model']=='WOFOST' and r['factor_changed']=='radiation_multiplier') else 'FAIL'} |
| Silent fallback copied original weather | No fallback is implemented; parser failure becomes profile failure with metadata | PASS |
| Failed profiles lacked metadata | Result rows include scenario, year, sowing, adjusted sowing, N, perturbation values, and error | PASS |
| WOFOST provenance used old flat-CABO explanation | Pilot A uses report 19 materialized WOFOST81 repo + venv72 patched PCSE | PASS |
| Endpoints came from year-end row | Endpoints are derived from daily series | {'PASS' if not endpoint_bad else 'FAIL'} |
| WOFOST Nfix was implied despite missing output | `nfix_total` is reported as `unavailable` when absent | PASS |

## 3. Selected Baselines

Selected years: {', '.join(str(y) for y in years)}. Each selected year contributes 3 sowing dates x 2 N rates = 6 scenarios.

| Weather year | Baseline scenarios |
|---:|---:|
{baseline_table}

Required coverage:

- Sowing DOY values: 135, 144, 152.
- N rates: 50 and 100 kg ha-1.
- Total selected baselines: {len(scenarios)}.

## 4. Selected Perturbations

| ID | Family | Factor changed | Level | Rad mult | Temp delta | Water mult | N mult | CO2 | Sowing delta |
|---|---|---|---|---:|---:|---:|---:|---:|---:|
{pert_table}

## 5. Input-copy and Isolation Audit

All official Design B inputs were copied into `/Users/mengchang/Desktop/Codex_Pilot_B_Rerun/inputs/` before execution. The formal Design B directory was read as source only.

Key copied inputs:

- Selected baseline matrix: `inputs/matrices/selected_baselines.csv`
- Selected perturbation matrix: `inputs/matrices/selected_perturbations.csv`
- APSIM baseline files: `inputs/apsim_baselines/`
- WOFOST baseline configs: `inputs/wofost_baselines/`
- APSIM weather files: `inputs/weather/apsim_met/original/`
- WOFOST PCSE weather files: `inputs/weather/pcse_csv/original/`
- WOFOST materialized repo: `inputs/wofost_runtime/materialized_cached_wofost81_repo/`
- WOFOST soil file: `inputs/wofost_runtime/wofost_soil_ames_clarion.soil`

SHA-256 manifest: `manifests/pilot_a_sha256_manifest.csv`.

## 6. APSIM Structured-edit Audit

APSIM was edited through parsed JSON, not raw string replacement.

Input QA file: `qa/input_perturbation_qa.csv`  
Pass/fail file: `qa/input_qa_pass_fail.csv`

APSIM input QA failures: {len([r for r in input_fail if r['model']=='APSIM'])}.

Expected checks:

- P001/P003/P005 weather files differ from source.
- P011 sowing manager date differs from anchor.
- N amount remains correctly written for all profiles even though N is not a selected Pilot A perturbation.
- Generated `.apsimx` files point to the perturbed local weather files.

## 7. WOFOST Weather-perturbation Audit

WOFOST PCSE weather files were parsed with metadata preserved and header-aware transformation.

WOFOST input QA failures: {len([r for r in input_fail if r['model']=='WOFOST'])}.

Expected checks:

- P001 modifies `IRRAD`.
- P003 modifies `TMIN` and `TMAX`.
- P005 modifies `RAIN` and WOFOST initial water availability (`WAV`).
- P011 modifies agromanagement sowing date.
- Parser failure is not silently converted into original-weather copy.

## 8. Execution Summary

| Model | OK | Non-OK | Total |
|---|---:|---:|---:|
| APSIM | {field_count(apsim, 'status', 'ok')} | {len(apsim)-field_count(apsim, 'status', 'ok')} | {len(apsim)} |
| WOFOST | {field_count(wofost, 'status', 'ok')} | {len(wofost)-field_count(wofost, 'status', 'ok')} | {len(wofost)} |

Result table: `reports/pilot_a_results.csv`.

## 9. Failure Analysis

Failure count: {len(failures)}.

{chr(10).join(failure_lines)}

Failed rows retain full profile metadata in `reports/pilot_a_results.csv`.

## 10. Endpoint Extraction Audit

Endpoints are derived from daily series.

APSIM endpoint logic:

- yield = maximum `Soybean.Grain.Wt`
- max LAI = maximum `Soybean.LAI`
- max biomass = maximum `Soybean.AboveGround.Wt`
- flowering = first `StartFlowering`
- maturity = first `Maturity`
- HI = max grain / max aboveground biomass

WOFOST endpoint logic:

- yield = maximum `WSO`
- max LAI = maximum `LAI`
- max biomass = maximum `TAGP`
- flowering = first `DVS >= 1`
- maturity = first `DVS >= 2`
- HI = max WSO / max TAGP
- ET/transpiration and N uptake are derived only where variables are present.
- `nfix_total` is `unavailable` if `NfixTotal` is absent.

Endpoint extraction failures among successful profiles: {len(endpoint_bad)}.

## 11. Output Non-identity Audit

Output non-identity QA file: `qa/output_non_identity_qa.csv`.

Comparable successful perturbation-vs-anchor pairs that remained byte-identical: {len(identity_fail)}.

Unavailable comparisons occur when either the anchor or perturbed profile failed.

## 12. Contamination Audit

Contamination scan file: `qa/contamination_scan.csv`.

Hits: {len(contamination_hits)}.

The scan targeted copied inputs, work files, QA files, and manifests for frozen/forbidden workflow tokens. The active runtime uses the reconstructed WOFOST81 materialized repo and patched venv72 PCSE, not B2, semantic transfer, hybrid APSIM, old Sobol, old SHAP, old classifier output, `wofost_crop_harmonized.crop`, official-provider default WOFOST, or unpatched PCSE.

## 13. Whether Hermes Pilot B Errors Were Avoided

| Error from 29 audit | Avoided? | Evidence |
|---|---|---|
| APSIM perturbations not entering model | {'YES' if not any(r for r in input_fail if r['model']=='APSIM') and not any(r for r in identity_fail if r['model']=='APSIM') else 'NO'} | Input QA and non-identity QA |
| WOFOST weather perturbations not entering model | {'YES' if not any(r for r in input_fail if r['model']=='WOFOST') else 'NO'} | PCSE weather hash and weather-summary QA |
| Failed-profile metadata missing | YES | Results table stores full metadata for all rows |
| Old WOFOST provenance repeated | YES | Script uses report 19 reconstructed materialized repo and patched PCSE |
| Endpoint from year-end row | YES | Daily-derived endpoint extraction |
| BNF/Nfix overclaim | YES | Nfix marked unavailable if absent |

## 14. Whether Pilot B Should Be Rerun

Pilot B should be rerun only if this report's final recommendation is GO or CONDITIONAL GO.

Current recommendation: **{final}**.

Required action before Pilot B:

{('- Repair the critical Pilot A failures listed above, then rerun Pilot A.' if final == 'NO-GO' else '- Apply this corrected runner pattern to Pilot B. If WOFOST weather-boundary failures occurred, decide whether to extend weather files or document censoring before rerunning Pilot B.')}

## 15. Final Recommendation

**{final}: {final_text}**
"""
    (DIRS["reports"] / "30_CODEX_PILOT_A_TEST_REPORT.md").write_text(report)


def main() -> None:
    started = datetime.now()
    scenarios, perturbations = select_inputs()
    paths = copy_inputs(scenarios, perturbations)
    profiles = make_profiles(scenarios, perturbations)
    if len(profiles) != 300:
        raise RuntimeError(f"Expected 300 profiles, got {len(profiles)}")
    write_csv_dict(DIRS["inputs"] / "matrices" / "pilot_a_profiles.csv", profiles)
    results, input_qa = run_profiles(profiles, paths)
    input_checks = evaluate_input_qa(input_qa)
    identity = compare_output_identity(results)
    contamination_hits = contamination_scan()
    write_manifest()
    summary = {
        "expected_profiles": 300,
        "result_rows": len(results),
        "ok": field_count(results, "status", "ok"),
        "failed": len(results) - field_count(results, "status", "ok"),
        "apsim_ok": field_count([r for r in results if r["model"] == "APSIM"], "status", "ok"),
        "wofost_ok": field_count([r for r in results if r["model"] == "WOFOST"], "status", "ok"),
        "input_qa_failures": sum(1 for r in input_checks if not (r["weather_pass"] and r["sowing_pass"] and r["n_pass"])),
        "identity_failures": sum(1 for r in identity if r.get("comparison_status") == "ok" and r.get("identical_to_anchor") is True),
        "contamination_hits": len(contamination_hits),
        "timestamp": datetime.now().isoformat(),
    }
    json.dump(summary, open(DIRS["reports"] / "pilot_a_summary.json", "w"), indent=2)
    generate_report(scenarios, perturbations, profiles, results, input_checks, identity, contamination_hits, started, datetime.now())
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
