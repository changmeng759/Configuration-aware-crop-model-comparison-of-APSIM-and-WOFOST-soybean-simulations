#!/usr/bin/env python3
"""Design B cloud full-simulation runner.

Modes:
  --mode preflight        Validate package inputs without running models.
  --mode parallel-smoke   Run 32 profiles, one intended per worker, before full run.
  --mode full             Run the full 150 x 150 x 2 experiment with resume.

This runner intentionally does not train classifiers or run XAI.
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import date, datetime
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import designb_core as core  # noqa: E402


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "inputs"
VENV = Path(sys.executable)
DEFAULT_WORKERS = 32
FALLBACK_WORKERS = [28, 24]
EXPECTED_SCENARIOS = 150
EXPECTED_PERTURBATIONS = 150
EXPECTED_FULL_PROFILES = 45_000
EXPECTED_SMOKE_PROFILES = 32

SOURCE_WEATHER = INPUTS / "Weather_Library"
SOURCE_PCSE = SOURCE_WEATHER / "pcse_csv"
SOURCE_APSIM_WEATHER = SOURCE_WEATHER / "apsim_met"
WOFOST_REPO = ROOT / "wofost_runtime" / "materialized_cached_wofost81_repo"
WOFOST_SOIL = ROOT / "wofost_runtime" / "wofost_soil_ames_clarion.soil"

DIRS = {
    "inputs": ROOT / "inputs",
    "reports": ROOT / "reports",
    "qa": ROOT / "qa",
    "logs": ROOT / "logs",
    "manifests": ROOT / "manifests",
    "status": ROOT / "manifests" / "status",
    "work": ROOT / "work",
    "wofost_daily": ROOT / "outputs" / "wofost" / "daily",
    "wofost_endpoints": ROOT / "outputs" / "wofost" / "endpoints",
}
for d in DIRS.values():
    d.mkdir(parents=True, exist_ok=True)


def read_baselines() -> list[dict[str, str]]:
    rows = sorted(core.read_csv_dict(core.BASELINE_CSV), key=lambda r: int(r["scenario_index"]))
    if len(rows) != EXPECTED_SCENARIOS:
        raise RuntimeError(f"Expected {EXPECTED_SCENARIOS} baseline scenarios, got {len(rows)}")
    return rows


def read_perturbations() -> list[dict[str, str]]:
    rows = sorted(core.read_csv_dict(core.PERT_CSV), key=lambda r: int(r["perturbation_index"]))
    if len(rows) != EXPECTED_PERTURBATIONS:
        raise RuntimeError(f"Expected {EXPECTED_PERTURBATIONS} perturbations, got {len(rows)}")
    return rows


def copy_inputs(scenarios: list[dict[str, str]], perturbations: list[dict[str, str]]) -> dict[str, Path]:
    paths = core.copy_inputs(scenarios, perturbations)
    pcse_dst = paths["pcse_weather"]
    apsim_dst = paths["apsim_weather"]

    for src in sorted(SOURCE_PCSE.glob("*_pcse_weather.csv")):
        shutil.copy2(src, pcse_dst / src.name)
    for src in sorted(SOURCE_APSIM_WEATHER.glob("*.met")):
        shutil.copy2(src, apsim_dst / src.name)

    required_years = sorted({int(float(s["weather_year"])) for s in scenarios})
    required_pcse_years = sorted(set(required_years) | {y + 1 for y in required_years})
    for y in required_years:
        if not (apsim_dst / f"{y}.met").exists():
            raise FileNotFoundError(f"Missing APSIM weather: {apsim_dst / f'{y}.met'}")
    for y in required_pcse_years:
        if not (pcse_dst / f"{y}_pcse_weather.csv").exists():
            raise FileNotFoundError(f"Missing WOFOST current/next-year weather: {pcse_dst / f'{y}_pcse_weather.csv'}")
    return paths


def preflight_assertions(
    scenarios: list[dict[str, str]],
    perturbations: list[dict[str, str]],
    profiles: list[dict[str, Any]],
    paths: dict[str, Path],
    mode: str,
) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def record(name: str, ok: bool, detail: str) -> None:
        checks.append({"check": name, "ok": ok, "detail": detail})

    years = sorted({int(float(s["weather_year"])) for s in scenarios})
    req_pcse_years = sorted(set(years) | {y + 1 for y in years})
    record("baseline_count", len(scenarios) == EXPECTED_SCENARIOS, str(len(scenarios)))
    record("perturbation_count", len(perturbations) == EXPECTED_PERTURBATIONS, str(len(perturbations)))
    record("profile_count_full_design", len(profiles) == EXPECTED_FULL_PROFILES, str(len(profiles)))
    record("weather_years", years == list(range(2000, 2025)), ",".join(map(str, years)))
    record("sowing_coverage", sorted({int(float(s["sowing_doy"])) for s in scenarios}) == [135, 144, 152], str(sorted({s["sowing_doy"] for s in scenarios})))
    record("n_coverage", sorted({float(s["n_rate_kg_ha"]) for s in scenarios}) == [50.0, 100.0], str(sorted({s["n_rate_kg_ha"] for s in scenarios})))
    record("wofost_repo", WOFOST_REPO.exists(), str(WOFOST_REPO))
    record("wofost_soil", WOFOST_SOIL.exists(), str(WOFOST_SOIL))
    record("python_executable", VENV.exists(), str(VENV))

    for y in years:
        record(f"apsim_weather_{y}", (paths["apsim_weather"] / f"{y}.met").exists(), str(paths["apsim_weather"] / f"{y}.met"))
    for y in req_pcse_years:
        record(f"pcse_weather_{y}", (paths["pcse_weather"] / f"{y}_pcse_weather.csv").exists(), str(paths["pcse_weather"] / f"{y}_pcse_weather.csv"))

    probe = subprocess.run(
        [str(VENV), "-c", "import pcse, json; print(json.dumps({'pcse_version': getattr(pcse, '__version__', 'unknown')}))"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    record("pcse_import", probe.returncode == 0, (probe.stdout or probe.stderr).strip())

    failed = [r for r in checks if not r["ok"]]
    core.write_csv_dict(ROOT / "qa" / f"{mode}_preflight_assertions.csv", checks, ["check", "ok", "detail"])
    summary = {
        "mode": mode,
        "years": years,
        "required_pcse_years": req_pcse_years,
        "failed_count": len(failed),
        "checks": checks,
    }
    json.dump(summary, open(ROOT / "qa" / f"{mode}_preflight_summary.json", "w"), indent=2)
    if failed:
        raise RuntimeError(f"Preflight failed: {failed[:10]}")
    return summary


def build_extended_pcse_weather(profile: dict[str, Any], paths: dict[str, str]) -> dict[str, Any]:
    year = int(profile["weather_year"])
    src1 = Path(paths["pcse_weather"]) / f"{year}_pcse_weather.csv"
    src2 = Path(paths["pcse_weather"]) / f"{year + 1}_pcse_weather.csv"
    if not src1.exists():
        raise FileNotFoundError(f"Missing current-year PCSE weather: {src1}")
    if not src2.exists():
        raise FileNotFoundError(f"Missing next-year PCSE weather: {src2}")
    meta1, header1, rows1 = core.read_pcse_weather(src1)
    _, header2, rows2 = core.read_pcse_weather(src2)
    if header1 != header2:
        raise RuntimeError(f"PCSE header mismatch: {src1} vs {src2}")

    before = core.summarize_pcse_rows(rows1 + rows2)
    rad = float(profile["radiation_multiplier"])
    temp = float(profile["temperature_delta_c"])
    water = float(profile["water_availability_multiplier"])
    out_rows: list[dict[str, str]] = []
    for row in rows1 + rows2:
        new = dict(row)
        new["IRRAD"] = f"{float(row['IRRAD']) * rad:.2f}"
        new["TMIN"] = f"{float(row['TMIN']) + temp:.2f}"
        new["TMAX"] = f"{float(row['TMAX']) + temp:.2f}"
        new["RAIN"] = f"{float(row['RAIN']) * water:.2f}"
        out_rows.append(new)

    out = ROOT / "inputs" / "weather" / "pcse_csv" / "extended_perturbed" / f"{profile['profile_id']}_pcse_weather.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="") as f:
        for line in meta1:
            if line.startswith("Description"):
                f.write(f"Description = 'Design B extended weather for {year}-{year + 1}'\n")
            elif line.startswith("Source"):
                f.write("Source      = 'NASA POWER current and next year concatenated for WOFOST boundary resolution'\n")
            else:
                f.write(line + "\n")
        w = csv.DictWriter(f, fieldnames=header1, lineterminator="\n")
        w.writeheader()
        w.writerows(out_rows)
    _, _, check = core.read_pcse_weather(out)
    after = core.summarize_pcse_rows(check)
    return {
        "weather_file": str(out),
        "weather_source_current": str(src1),
        "weather_source_next": str(src2),
        "weather_source_current_hash": core.sha256_file(src1),
        "weather_source_next_hash": core.sha256_file(src2),
        "weather_output_hash": core.sha256_file(out),
        "weather_first_day": check[0]["DAY"],
        "weather_last_day": check[-1]["DAY"],
        "weather_n_rows": len(check),
        "weather_source_irrad_sum": before["irrad_sum"],
        "weather_output_irrad_sum": after["irrad_sum"],
        "weather_source_tmean_mean": before["tmean_mean"],
        "weather_output_tmean_mean": after["tmean_mean"],
        "weather_source_rain_sum": before["rain_sum"],
        "weather_output_rain_sum": after["rain_sum"],
    }


def run_wofost_extended(profile: dict[str, Any], paths: dict[str, str]) -> tuple[dict[str, Any], dict[str, Any]]:
    pid = profile["profile_id"]
    year = int(profile["weather_year"])
    adjusted = core.date_from_doy(year, int(profile["adjusted_sowing_doy"]))
    n_amount = float(profile["n_rate_kg_ha"]) * float(profile["nitrogen_availability_multiplier"])
    co2_ppm = float(profile["co2_ppm"])
    weather_meta = build_extended_pcse_weather(profile, paths)
    daily_out = DIRS["wofost_daily"] / f"{pid}.csv"
    endpoint_out = DIRS["wofost_endpoints"] / f"{pid}.json"
    stdout_log = DIRS["logs"] / f"{pid}.stdout.log"
    stderr_log = DIRS["logs"] / f"{pid}.stderr.log"
    input_qa = {
        **profile,
        "model": "WOFOST",
        **weather_meta,
        "actual_sowing_date": adjusted.isoformat(),
        "expected_sowing_date": adjusted.isoformat(),
        "actual_n_amount": f"{n_amount:g}",
        "expected_n_amount": f"{n_amount:g}",
        "actual_co2_ppm": f"{co2_ppm:.1f}",
        "expected_co2_ppm": f"{co2_ppm:.1f}",
    }
    script = f"""
import csv, json, time
from datetime import date
from pcse.base import ParameterProvider
from pcse.input import CABOFileReader, CSVWeatherDataProvider, YAMLCropDataProvider
from pcse.input.sitedataproviders import WOFOST72SiteDataProvider
from pcse.models import Wofost81_NWLP_CWB_CNB
t0 = time.time()
cropd = YAMLCropDataProvider(Wofost81_NWLP_CWB_CNB, fpath={str(WOFOST_REPO)!r}, force_reload=True)
cropd.set_active_crop('soybean', 'Soybean_906')
crop = dict(cropd)
for k, v in {{'TSUMEM': 90, 'TSUM1': 400, 'TSUM2': 1260, 'NFIX_FR': 0.8, 'CO2': {co2_ppm}}}.items():
    crop[k] = v
soil = CABOFileReader({str(WOFOST_SOIL)!r})
for k, v in {{'NSOILBASE':20,'NSOILBASE_FR':0.02,'NAVAILI':20,'BG_N_SUPPLY':0.03,
 'N_RECOVERY_FRACTION':0.7,'KDENIT_REF':0.06,'KNIT_REF':0.08,
 'WFPS_CRIT':0.8,'KSORP':0.5,'KSUB':15,'CNRatioBio':10,
 'FGL':0,'FRNX':0.5,'NO3ConcR':1,'NH4ConcR':1,'N_demand_soil':1}}.items():
    soil[k] = v
site = WOFOST72SiteDataProvider(WAV=9.0*{float(profile['water_availability_multiplier'])})
sow = date({adjusted.year}, {adjusted.month}, {adjusted.day})
agro = [{{date({year},1,1): {{
    'CropCalendar': {{'crop_name':'soybean','variety_name':'Soybean_906',
        'crop_start_date':sow,'crop_start_type':'sowing','crop_end_date':date({year},11,15),
        'crop_end_type':'maturity','max_duration':220}},
    'TimedEvents':[{{'event_signal':'apply_n','name':'N application at sowing','comment':'Design B full simulation',
        'events_table':[{{sow:{{'N_amount':{n_amount},'N_recovery':0.7}}}}]}}],
    'StateEvents': None
}}}}]
wdp = CSVWeatherDataProvider({weather_meta['weather_file']!r}, force_reload=True)
params = ParameterProvider(cropdata=crop, soildata=soil, sitedata=site)
engine = Wofost81_NWLP_CWB_CNB(params, wdp, agro)
engine.run_till_terminate()
out = engine.get_output()
cols = ['day','DVS','LAI','TAGP','WSO','WLV','WST','WRT','TRA','EVS','SM','NuptakeTotal','NfixTotal','NAVAIL','Ndemand']
present = []
for c in cols:
    if c == 'day' or any(c in r for r in out):
        present.append(c)
with open({str(daily_out)!r}, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=['doy'] + present)
    w.writeheader()
    for r in out:
        row = {{}}
        d = r.get('day')
        row['doy'] = d.timetuple().tm_yday if hasattr(d, 'timetuple') else ''
        for c in present:
            val = r.get(c, '')
            if hasattr(val, 'isoformat'):
                val = val.isoformat()
            row[c] = val
        w.writerow(row)
print(json.dumps({{'status':'ok','runtime_s':time.time()-t0,'rows':len(out)}}))
"""
    t0 = time.time()
    proc = subprocess.run([str(VENV), "-c", script], capture_output=True, text=True, timeout=180)
    runtime = time.time() - t0
    stdout_log.write_text(proc.stdout)
    stderr_log.write_text(proc.stderr)
    result = {**profile, "model": "WOFOST", "runtime_s": round(runtime, 6), "status": "unknown", "error": ""}
    if proc.returncode != 0 or not daily_out.exists():
        result.update({"status": "error", "error": (proc.stderr or proc.stdout)[-2000:]})
        return result, input_qa
    endpoint = core.derive_wofost_endpoint(daily_out, pid, profile)
    endpoint["runtime_s"] = round(runtime, 6)
    endpoint["daily_csv"] = str(daily_out)
    json.dump(endpoint, open(endpoint_out, "w"), indent=2)
    result.update({
        "status": "ok",
        "daily_csv": str(daily_out),
        "endpoint_json": str(endpoint_out),
        "daily_hash": core.sha256_file(daily_out),
        "endpoint_hash": core.sha256_file(endpoint_out),
        **endpoint,
    })
    return result, input_qa


def pathdict_to_str(paths: dict[str, Path]) -> dict[str, str]:
    return {k: str(v) for k, v in paths.items()}


def status_path(profile_id: str, namespace: str) -> Path:
    path = DIRS["status"] / namespace
    path.mkdir(parents=True, exist_ok=True)
    return path / f"{profile_id}.json"


def run_profile_once(profile: dict[str, Any], paths: dict[str, str]) -> tuple[dict[str, Any], dict[str, Any]]:
    if profile["model"] == "APSIM":
        return core.run_apsim(profile, {k: Path(v) for k, v in paths.items()})
    return run_wofost_extended(profile, paths)


def run_profile(args: tuple[dict[str, Any], dict[str, str], str, int]) -> tuple[dict[str, Any], dict[str, Any]]:
    profile, paths, namespace, max_retries = args
    last_result: dict[str, Any] | None = None
    last_qa: dict[str, Any] | None = None
    for attempt in range(max_retries + 1):
        try:
            result, qa = run_profile_once(profile, paths)
        except Exception as e:
            result = {**profile, "status": "crash", "runtime_s": 0, "error": repr(e)}
            qa = {**profile, "qa_error": repr(e)}
        result["worker_pid"] = os.getpid()
        result["attempt"] = attempt + 1
        qa["worker_pid"] = os.getpid()
        qa["attempt"] = attempt + 1
        last_result, last_qa = result, qa
        if result.get("status") == "ok":
            break
    assert last_result is not None and last_qa is not None
    json.dump(
        {"result": last_result, "input_qa": last_qa, "timestamp": datetime.now().isoformat()},
        open(status_path(profile["profile_id"], namespace), "w"),
        indent=2,
    )
    return last_result, last_qa


def load_completed(profiles: list[dict[str, Any]], namespace: str) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    todo: list[dict[str, Any]] = []
    results: list[dict[str, Any]] = []
    input_qa: list[dict[str, Any]] = []
    for p in profiles:
        sp = status_path(p["profile_id"], namespace)
        if sp.exists():
            rec = json.load(open(sp))
            if rec.get("result", {}).get("status") == "ok":
                results.append(rec["result"])
                input_qa.append(rec.get("input_qa", {}))
                continue
        todo.append(p)
    return todo, results, input_qa


def run_parallel(
    profiles: list[dict[str, Any]],
    paths: dict[str, Path],
    workers: int,
    namespace: str,
    max_retries: int = 2,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    started = datetime.now()
    todo, initial_results, initial_input_qa = load_completed(profiles, namespace)
    results = list(initial_results)
    input_qa = list(initial_input_qa)
    worker_counts: dict[str, int] = {}
    args = [(p, pathdict_to_str(paths), namespace, max_retries) for p in todo]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        future_map = {ex.submit(run_profile, a): a[0] for a in args}
        completed = len(results)
        for fut in as_completed(future_map):
            p = future_map[fut]
            try:
                result, qa = fut.result()
            except Exception as e:
                result = {**p, "status": "crash", "runtime_s": 0, "error": repr(e)}
                qa = {**p, "qa_error": repr(e)}
                json.dump({"result": result, "input_qa": qa, "timestamp": datetime.now().isoformat()}, open(status_path(p["profile_id"], namespace), "w"), indent=2)
            result["worker_count_setting"] = workers
            qa["worker_count_setting"] = workers
            results.append(result)
            input_qa.append(qa)
            worker = str(result.get("worker_pid", "unknown"))
            worker_counts[worker] = worker_counts.get(worker, 0) + 1
            completed += 1
            if completed % 250 == 0 or completed == len(profiles):
                core.write_csv_dict(ROOT / "reports" / f"{namespace}_partial_results.csv", results)
                print(f"[{completed}/{len(profiles)}] {namespace} workers={workers} ok={sum(r.get('status') == 'ok' for r in results)}", flush=True)

    final_results: list[dict[str, Any]] = []
    final_input_qa: list[dict[str, Any]] = []
    for p in profiles:
        sp = status_path(p["profile_id"], namespace)
        if sp.exists():
            rec = json.load(open(sp))
            final_results.append(rec.get("result", {}))
            final_input_qa.append(rec.get("input_qa", {}))
        else:
            final_results.append({**p, "status": "missing_status", "runtime_s": 0, "error": "status JSON not written"})
            final_input_qa.append({**p, "qa_error": "status JSON not written"})
    ended = datetime.now()
    runtime = {
        "namespace": namespace,
        "workers": workers,
        "worker_profile_counts": worker_counts,
        "wall_clock_seconds": (ended - started).total_seconds(),
        "started": started.isoformat(),
        "ended": ended.isoformat(),
    }
    return final_results, final_input_qa, runtime


def contamination_scan(namespace: str) -> list[dict[str, str]]:
    tokens = [
        "B2覆写apsim", "semantic transfer", "hybrid APSIM", "old Sobol", "old SHAP",
        "old classifier", "wofost_crop_harmonized.crop", "Hermes old runner",
    ]
    roots = [ROOT / "inputs", ROOT / "work", ROOT / "qa", ROOT / "manifests", ROOT / "outputs"]
    out = ROOT / "qa" / f"{namespace}_contamination_scan.csv"
    hits: list[dict[str, str]] = []
    for root in roots:
        for path in root.rglob("*"):
            if path == out:
                continue
            if not path.is_file() or path.stat().st_size > 2_000_000:
                continue
            try:
                text = path.read_text(errors="ignore")
            except Exception:
                continue
            for token in tokens:
                if token in text:
                    hits.append({"file": str(path), "token": token})
    core.write_csv_dict(out, hits, ["file", "token"])
    return hits


def manifest(namespace: str) -> None:
    rows: list[dict[str, Any]] = []
    for base in [ROOT / "inputs", ROOT / "outputs", ROOT / "qa", ROOT / "reports", ROOT / "scripts", ROOT / "configs", ROOT / "wofost_runtime"]:
        for p in base.rglob("*"):
            if p.is_file():
                rows.append({"path": str(p), "size_bytes": p.stat().st_size, "sha256": core.sha256_file(p)})
    core.write_csv_dict(ROOT / "manifests" / f"{namespace}_sha256_manifest.csv", rows)


def select_parallel_smoke_profiles(all_profiles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    wanted: list[dict[str, Any]] = []
    preferred_p = ["P000", "P009", "P010", "P011", "P012"]
    preferred_years = [2000, 2009, 2024]
    for model in ["APSIM", "WOFOST"]:
        for p in all_profiles:
            if p["model"] == model and int(p["weather_year"]) in preferred_years and p["perturbation_id"] in preferred_p:
                wanted.append(p)
                if len([x for x in wanted if x["model"] == model]) >= EXPECTED_SMOKE_PROFILES // 2:
                    break
    if len(wanted) < EXPECTED_SMOKE_PROFILES:
        seen = {p["profile_id"] for p in wanted}
        for p in all_profiles:
            if p["profile_id"] not in seen:
                wanted.append(p)
                seen.add(p["profile_id"])
            if len(wanted) == EXPECTED_SMOKE_PROFILES:
                break
    if len(wanted) != EXPECTED_SMOKE_PROFILES:
        raise RuntimeError(f"Expected {EXPECTED_SMOKE_PROFILES} smoke profiles, got {len(wanted)}")
    return wanted


def summarize_run(namespace: str, expected: int, results: list[dict[str, Any]], input_qa: list[dict[str, Any]], runtime: dict[str, Any]) -> dict[str, Any]:
    core.write_csv_dict(ROOT / "reports" / f"{namespace}_results.csv", results)
    core.write_csv_dict(ROOT / "qa" / f"{namespace}_input_qa.csv", input_qa)
    input_checks = core.evaluate_input_qa(input_qa)
    core.write_csv_dict(ROOT / "qa" / f"{namespace}_input_qa_pass_fail.csv", input_checks)
    contamination = contamination_scan(namespace)
    manifest(namespace)
    failed = [r for r in results if r.get("status") != "ok"]
    input_failures = [
        r for r in input_checks
        if not (r.get("weather_pass") and r.get("sowing_pass") and r.get("n_pass") and r.get("co2_pass", True))
    ]
    summary = {
        "namespace": namespace,
        "expected_profiles": expected,
        "result_rows": len(results),
        "ok": len(results) - len(failed),
        "failed": len(failed),
        "input_qa_failures": len(input_failures),
        "contamination_hits": len(contamination),
        "runtime": runtime,
        "recommendation": "GO" if len(results) == expected and not failed and not input_failures and not contamination else "NO-GO",
    }
    json.dump(summary, open(ROOT / "reports" / f"{namespace}_summary.json", "w"), indent=2)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["preflight", "parallel-smoke", "full"], required=True)
    parser.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
    parser.add_argument("--max-retries", type=int, default=2)
    args = parser.parse_args()

    scenarios = read_baselines()
    perturbations = read_perturbations()
    profiles = core.make_profiles(scenarios, perturbations)
    if len(profiles) != EXPECTED_FULL_PROFILES:
        raise RuntimeError(f"Expected {EXPECTED_FULL_PROFILES} full profiles, got {len(profiles)}")
    paths = copy_inputs(scenarios, perturbations)
    preflight = preflight_assertions(scenarios, perturbations, profiles, paths, args.mode)
    json.dump(preflight, open(ROOT / "reports" / f"{args.mode}_preflight.json", "w"), indent=2)
    core.write_csv_dict(ROOT / "inputs" / "matrices" / "full_profiles.csv", profiles)

    if args.mode == "preflight":
        print(json.dumps({"status": "preflight_ok", "profiles": len(profiles)}, indent=2))
        return

    run_profiles = profiles if args.mode == "full" else select_parallel_smoke_profiles(profiles)
    expected = EXPECTED_FULL_PROFILES if args.mode == "full" else EXPECTED_SMOKE_PROFILES
    namespace = "full_simulation" if args.mode == "full" else "parallel_smoke_32"
    results, input_qa, runtime = run_parallel(run_profiles, paths, args.workers, namespace, args.max_retries)
    summary = summarize_run(namespace, expected, results, input_qa, runtime)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
