#!/usr/bin/env python3
from pathlib import Path
import csv, json
root = Path(__file__).resolve().parents[1]
rows = []
for sp in sorted((root / 'manifests' / 'status').rglob('*.json')):
    rec = json.load(open(sp))
    row = rec.get('result', {})
    row['status_file'] = str(sp)
    rows.append(row)
keys = []
for r in rows:
    for k in r:
        if k not in keys:
            keys.append(k)
out = root / 'reports' / 'merged_status_results.csv'
out.parent.mkdir(parents=True, exist_ok=True)
with open(out, 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=keys, extrasaction='ignore')
    w.writeheader(); w.writerows(rows)
print(out)
