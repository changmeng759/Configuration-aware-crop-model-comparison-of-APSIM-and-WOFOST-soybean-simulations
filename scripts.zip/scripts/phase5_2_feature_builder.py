#!/usr/bin/env python3
"""Phase 5.2 feature engineering for Design B full simulation outputs."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT = Path("/Users/mengchang/Desktop/DesignB_full_simulation_results")

EXCLUDED_LEAKAGE_FIELDS = {
    "model",
    "target__model",
    "target__model_binary",
    "profile_id",
    "meta__profile_id",
    "daily_csv",
    "endpoint_json",
    "daily_hash",
    "endpoint_hash",
    "runtime_s",
    "status",
    "error",
    "worker_pid",
    "attempt",
    "endpoint_source",
    "nfix_total",
    "reported_co2_values",
    "cumulative_et",
    "cumulative_transpiration",
    "cumulative_n_uptake",
    "actual_report_has_weather_co2",
    "weather_output_has_co2",
    "weather_output_co2_values",
    "weather_file",
    "expected_weather_file",
    "apsimx_hash",
    "weather_source_hash",
    "weather_output_hash",
    "weather_source_current_hash",
    "weather_source_next_hash",
    "feature__daily_window_rule_code",
}


@dataclass(frozen=True)
class OutputPaths:
    feature_table: Path
    dictionary: Path
    missingness: Path
    leakage_audit: Path
    report: Path
    qa_json: Path


def output_paths(root: Path = ROOT) -> OutputPaths:
    return OutputPaths(
        feature_table=root / "features/full_simulation_feature_table.csv",
        dictionary=root / "features/full_simulation_feature_dictionary.csv",
        missingness=root / "features/full_simulation_missingness_report.csv",
        leakage_audit=root / "features/full_simulation_leakage_audit.csv",
        report=root / "reports/44_FEATURE_ENGINEERING_REPORT.md",
        qa_json=root / "features/full_simulation_feature_qa.json",
    )


def is_missing(value: Any) -> bool:
    return value is None or (isinstance(value, float) and math.isnan(value)) or pd.isna(value)


def is_allowed_classifier_feature(column: str) -> bool:
    return column.startswith("feature__") and column not in EXCLUDED_LEAKAGE_FIELDS


def localize_cloud_path(path_value: str, root: Path = ROOT) -> Path:
    if path_value.startswith("/root/DesignB_cloud_package/"):
        return root / path_value.replace("/root/DesignB_cloud_package/", "")
    return Path(path_value)


def parse_date(value: Any) -> date:
    if isinstance(value, date):
        return value
    return datetime.strptime(str(value), "%Y-%m-%d").date()


def date_from_year_doy(year: int, doy: float) -> date | None:
    if is_missing(doy):
        return None
    return date(int(year), 1, 1) + timedelta(days=int(round(float(doy))) - 1)


def numeric_or_nan(value: Any) -> float:
    try:
        if value == "unavailable":
            return math.nan
        return float(value)
    except (TypeError, ValueError):
        return math.nan


def last_valid(series: pd.Series) -> float:
    valid = pd.to_numeric(series, errors="coerce").dropna()
    if valid.empty:
        return math.nan
    return float(valid.iloc[-1])


def summarize_series(prefix: str, series: pd.Series) -> dict[str, float | int]:
    values = pd.to_numeric(series, errors="coerce")
    observed = int(values.notna().sum())
    if observed == 0:
        return {
            f"feature__daily_{prefix}_observed_days": 0,
            f"feature__daily_{prefix}_max": math.nan,
            f"feature__daily_{prefix}_mean": math.nan,
            f"feature__daily_{prefix}_final": math.nan,
            f"feature__daily_{prefix}_sum": math.nan,
        }
    return {
        f"feature__daily_{prefix}_observed_days": observed,
        f"feature__daily_{prefix}_max": float(values.max(skipna=True)),
        f"feature__daily_{prefix}_mean": float(values.mean(skipna=True)),
        f"feature__daily_{prefix}_final": last_valid(values),
        f"feature__daily_{prefix}_sum": float(values.sum(skipna=True)),
    }


def standardize_daily(model: str, daily: pd.DataFrame) -> pd.DataFrame:
    if model == "APSIM":
        out = pd.DataFrame(
            {
                "date": pd.to_datetime(daily["Clock.Today"]).dt.date,
                "lai": pd.to_numeric(daily["Soybean.LAI"], errors="coerce"),
                "biomass": pd.to_numeric(daily["Soybean.AboveGround.Wt"], errors="coerce"),
                "grain": pd.to_numeric(daily["Soybean.Grain.Wt"], errors="coerce"),
            }
        )
    elif model == "WOFOST":
        out = pd.DataFrame(
            {
                "date": pd.to_datetime(daily["day"]).dt.date,
                "lai": pd.to_numeric(daily["LAI"], errors="coerce"),
                "biomass": pd.to_numeric(daily["TAGP"], errors="coerce"),
                "grain": pd.to_numeric(daily["WSO"], errors="coerce"),
            }
        )
    else:
        raise ValueError(f"Unsupported model: {model}")
    out["doy"] = pd.to_datetime(out["date"]).dt.dayofyear
    return out


def build_daily_features(
    model: str,
    daily: pd.DataFrame,
    sowing_date: date,
    maturity_doy: float,
) -> dict[str, Any]:
    std = standardize_daily(model, daily)
    raw_row_count = int(len(std))
    observed_last_date = max(std["date"]) if raw_row_count else None
    observed_last_doy = int(pd.Timestamp(observed_last_date).dayofyear) if observed_last_date else math.nan

    maturity_date = date_from_year_doy(sowing_date.year, maturity_doy)
    maturity_observed = maturity_date is not None
    if maturity_date is None:
        window_end = observed_last_date
        window_ended_at_observed_end = True
    else:
        window_end = min(maturity_date, observed_last_date)
        window_ended_at_observed_end = maturity_date > observed_last_date

    window = std[(std["date"] >= sowing_date) & (std["date"] <= window_end)].copy()
    window_n_days = int(len(window))
    crop_state_observed_days = int(window[["lai", "biomass", "grain"]].notna().any(axis=1).sum())

    features: dict[str, Any] = {
        "meta__daily_raw_row_count": raw_row_count,
        "meta__daily_raw_last_doy": observed_last_doy,
        "feature__daily_window_rule_code": "sowing_to_maturity_else_observed_end",
        "feature__daily_window_start_doy": int(pd.Timestamp(sowing_date).dayofyear),
        "feature__daily_window_end_doy": int(pd.Timestamp(window_end).dayofyear) if window_end else math.nan,
        "feature__daily_window_n_days": window_n_days,
        "feature__daily_window_used_maturity": int(maturity_observed),
        "feature__daily_window_ended_at_observed_end": int(window_ended_at_observed_end),
        "feature__daily_crop_state_observed_days": crop_state_observed_days,
        "feature__daily_crop_state_missing_days": window_n_days - crop_state_observed_days,
    }
    for prefix in ["lai", "biomass", "grain"]:
        features.update(summarize_series(prefix, window[prefix]))
    return features


def build_state_features(model: str, yield_value: Any, maturity_doy: Any) -> dict[str, int]:
    y = numeric_or_nan(yield_value)
    maturity_missing = is_missing(maturity_doy)
    return {
        "feature__state_maturity_observed": int(not maturity_missing),
        "feature__state_non_maturity": int(maturity_missing),
        "feature__state_zero_yield": int(not math.isnan(y) and abs(y) <= 1e-12),
        "feature__state_wofost_non_maturity": int(model == "WOFOST" and maturity_missing),
        "feature__state_wofost_zero_yield": int(model == "WOFOST" and not math.isnan(y) and abs(y) <= 1e-12),
    }


def read_daily_for_row(row: pd.Series, root: Path = ROOT) -> pd.DataFrame:
    path = localize_cloud_path(str(row["daily_csv"]), root)
    if row["model"] == "APSIM":
        usecols = ["Clock.Today", "Soybean.LAI", "Soybean.AboveGround.Wt", "Soybean.Grain.Wt"]
    else:
        usecols = ["day", "LAI", "TAGP", "WSO"]
    return pd.read_csv(path, usecols=usecols)


def build_feature_row(row: pd.Series, daily: pd.DataFrame) -> dict[str, Any]:
    sowing_date = parse_date(row["adjusted_sowing_date"])
    maturity_doy = numeric_or_nan(row["maturity_doy"])
    model = str(row["model"])
    target_binary = 1 if model == "WOFOST" else 0

    out: dict[str, Any] = {
        "meta__profile_id": row["profile_id"],
        "meta__scenario_id": row["scenario_id"],
        "meta__perturbation_id": row["perturbation_id"],
        "target__model": model,
        "target__model_binary": target_binary,
        "feature__weather_year": int(row["weather_year"]),
        "feature__original_sowing_doy": int(row["original_sowing_doy"]),
        "feature__adjusted_sowing_doy": int(row["adjusted_sowing_doy"]),
        "feature__n_rate_kg_ha": float(row["n_rate_kg_ha"]),
        "feature__perturbation_family": row["perturbation_family"],
        "feature__factor_changed": row["factor_changed"],
        "feature__level": row["level"],
        "feature__radiation_multiplier": float(row["radiation_multiplier"]),
        "feature__temperature_delta_c": float(row["temperature_delta_c"]),
        "feature__water_availability_multiplier": float(row["water_availability_multiplier"]),
        "feature__nitrogen_availability_multiplier": float(row["nitrogen_availability_multiplier"]),
        "feature__co2_ppm": float(row["co2_ppm"]),
        "feature__sowing_date_delta_days": float(row["sowing_date_delta_days"]),
        "feature__endpoint_yield": numeric_or_nan(row["yield"]),
        "feature__endpoint_max_lai": numeric_or_nan(row["max_lai"]),
        "feature__endpoint_max_biomass": numeric_or_nan(row["max_biomass"]),
        "feature__endpoint_flowering_doy": numeric_or_nan(row["flowering_doy"]),
        "feature__endpoint_maturity_doy": maturity_doy,
        "feature__endpoint_harvest_index": numeric_or_nan(row["harvest_index"]),
    }
    out.update(build_state_features(model, row["yield"], maturity_doy))
    out.update(build_daily_features(model, daily, sowing_date, maturity_doy))
    return out


def build_dictionary(feature_table: pd.DataFrame) -> pd.DataFrame:
    rows = []
    descriptions = {
        "meta__profile_id": "Unique simulation profile identifier; not a classifier feature.",
        "meta__scenario_id": "Baseline scenario identifier; metadata for grouping and audit.",
        "meta__perturbation_id": "Perturbation identifier; metadata for grouping and audit.",
        "target__model": "Classifier label: APSIM or WOFOST.",
        "target__model_binary": "Classifier label encoded as APSIM=0, WOFOST=1.",
        "feature__daily_window_rule_code": "Daily feature window rule: sowing date through maturity; if maturity is missing, through observed daily-series end.",
    }
    for col in feature_table.columns:
        if col.startswith("meta__"):
            role = "metadata"
        elif col.startswith("target__"):
            role = "target"
        elif col.startswith("feature__state"):
            role = "classifier_feature_state"
        elif col.startswith("feature__daily"):
            role = "classifier_feature_daily"
        elif col.startswith("feature__endpoint"):
            role = "classifier_feature_endpoint"
        elif col.startswith("feature__"):
            role = "classifier_feature_design"
        else:
            role = "unknown"
        allowed = is_allowed_classifier_feature(col)
        rows.append(
            {
                "column": col,
                "role": role,
                "allowed_for_classifier": allowed,
                "dtype": str(feature_table[col].dtype),
                "source": infer_source(col),
                "missing_handling": infer_missing_handling(col),
                "leakage_risk": infer_leakage_risk(col, allowed),
                "description": descriptions.get(col, default_description(col)),
            }
        )
    return pd.DataFrame(rows)


def infer_source(col: str) -> str:
    if col.startswith("meta__") or col.startswith("target__"):
        return "reports/full_simulation_results.csv"
    if "daily_" in col:
        return "model-specific daily CSV mapped to common LAI/biomass/grain fields"
    if "endpoint_" in col or "state_" in col:
        return "reports/full_simulation_results.csv endpoint columns"
    return "Design B profile metadata and perturbation parameters"


def infer_missing_handling(col: str) -> str:
    if col == "feature__endpoint_maturity_doy":
        return "Missing retained for non-maturity; represented by state flags, no imputation."
    if col.startswith("feature__daily_") and col.endswith(("_max", "_mean", "_final", "_sum")):
        return "Daily blanks are not imputed; summaries use observed numeric values and companion observed/missing-day counts."
    if col.startswith("feature__state"):
        return "Binary state derived explicitly from endpoint values."
    return "No imputation; source values retained."


def infer_leakage_risk(col: str, allowed: bool) -> str:
    if col.startswith("target__"):
        return "Target label; never use as input feature."
    if col.startswith("meta__"):
        return "Metadata; do not use as classifier input or XAI explanation feature."
    if allowed:
        return "Allowed classifier candidate; not a direct target encoding."
    return "Excluded from classifier feature set."


def default_description(col: str) -> str:
    return col.replace("feature__", "").replace("meta__", "").replace("target__", "").replace("_", " ")


def build_missingness_report(feature_table: pd.DataFrame, dictionary: pd.DataFrame) -> pd.DataFrame:
    roles = dictionary.set_index("column")["role"].to_dict()
    allowed = dictionary.set_index("column")["allowed_for_classifier"].to_dict()
    model = feature_table["target__model"]
    rows = []
    for col in feature_table.columns:
        missing = feature_table[col].isna() | feature_table[col].astype(str).eq("")
        apsim = missing[model.eq("APSIM")]
        wofost = missing[model.eq("WOFOST")]
        rows.append(
            {
                "column": col,
                "role": roles.get(col, ""),
                "allowed_for_classifier": allowed.get(col, False),
                "missing_count": int(missing.sum()),
                "missing_rate": float(missing.mean()),
                "apsim_missing_count": int(apsim.sum()),
                "apsim_missing_rate": float(apsim.mean()),
                "wofost_missing_count": int(wofost.sum()),
                "wofost_missing_rate": float(wofost.mean()),
                "missingness_interpretation": missingness_interpretation(col, int(missing.sum())),
            }
        )
    return pd.DataFrame(rows)


def missingness_interpretation(col: str, missing_count: int) -> str:
    if missing_count == 0:
        return "Complete."
    if col == "feature__endpoint_maturity_doy":
        return "Expected WOFOST non-maturity state; retained and flagged."
    if col.startswith("feature__daily_"):
        return "No silent imputation; daily summary could not be computed when all mapped source values were missing."
    return "Retained as missing; no imputation applied."


def build_leakage_audit(source_columns: list[str], feature_columns: list[str]) -> pd.DataFrame:
    rows = []
    source_to_feature = {
        "scenario_id": "meta__scenario_id",
        "perturbation_id": "meta__perturbation_id",
        "weather_year": "feature__weather_year",
        "original_sowing_doy": "feature__original_sowing_doy",
        "adjusted_sowing_doy": "feature__adjusted_sowing_doy",
        "n_rate_kg_ha": "feature__n_rate_kg_ha",
        "perturbation_family": "feature__perturbation_family",
        "factor_changed": "feature__factor_changed",
        "level": "feature__level",
        "radiation_multiplier": "feature__radiation_multiplier",
        "temperature_delta_c": "feature__temperature_delta_c",
        "water_availability_multiplier": "feature__water_availability_multiplier",
        "nitrogen_availability_multiplier": "feature__nitrogen_availability_multiplier",
        "co2_ppm": "feature__co2_ppm",
        "sowing_date_delta_days": "feature__sowing_date_delta_days",
        "yield": "feature__endpoint_yield",
        "max_lai": "feature__endpoint_max_lai",
        "max_biomass": "feature__endpoint_max_biomass",
        "flowering_doy": "feature__endpoint_flowering_doy",
        "maturity_doy": "feature__endpoint_maturity_doy",
        "harvest_index": "feature__endpoint_harvest_index",
    }
    for col in source_columns:
        mapped_col = source_to_feature.get(col)
        used = col in feature_columns or (mapped_col in feature_columns if mapped_col else False)
        if col == "model":
            reason = "Direct target label; represented only as target__model."
        elif col in {"profile_id"}:
            reason = "Identifier includes model prefix and can directly leak target."
        elif col in EXCLUDED_LEAKAGE_FIELDS:
            reason = "Technical metadata, path/hash/runtime/status, or model-specific unavailable field."
        elif mapped_col:
            reason = f"Mapped to `{mapped_col}` with classifier permission controlled by the feature dictionary."
        elif used:
            reason = "Allowed feature or metadata after prefixing."
        else:
            reason = "Not used in classifier-ready feature table."
        rows.append(
            {
                "source_column": col,
                "source_file": "reports/full_simulation_results.csv",
                "included_in_feature_table": used,
                "allowed_for_classifier": bool(mapped_col and is_allowed_classifier_feature(mapped_col)),
                "leakage_or_exclusion_reason": reason,
                "action": "mapped_or_retained" if used else "excluded",
            }
        )

    explicit_exclusions = [
        ("target__model", "Feature table target column; excluded from model inputs."),
        ("target__model_binary", "Feature table target encoding; excluded from model inputs."),
        ("meta__profile_id", "Identifier; excluded from model inputs."),
        ("meta__scenario_id", "Grouping metadata; excluded from model inputs."),
        ("meta__perturbation_id", "Grouping metadata; excluded from model inputs."),
        ("meta__daily_raw_row_count", "Raw daily-file shape metadata; not a biological feature."),
        ("meta__daily_raw_last_doy", "Raw daily-file shape metadata; not a biological feature."),
        ("feature__daily_window_rule_code", "Constant rule label; document in dictionary but exclude from model inputs."),
    ]
    for col, reason in explicit_exclusions:
        rows.append(
            {
                "source_column": col,
                "source_file": "features/full_simulation_feature_table.csv",
                "included_in_feature_table": True,
                "allowed_for_classifier": False,
                "leakage_or_exclusion_reason": reason,
                "action": "retain_for_audit_exclude_from_classifier",
            }
        )
    return pd.DataFrame(rows)


def build_feature_table(root: Path = ROOT) -> tuple[pd.DataFrame, dict[str, Any]]:
    results_path = root / "reports/full_simulation_results.csv"
    summary_path = root / "reports/full_simulation_summary.json"
    pf_path = root / "qa/full_simulation_input_qa_pass_fail.csv"

    results = pd.read_csv(results_path)
    pf = pd.read_csv(pf_path)
    summary = json.load(open(summary_path))

    if summary.get("recommendation") != "GO" or int(summary.get("input_qa_failures", -1)) != 0:
        raise RuntimeError("Phase 5.2 requires repaired QA summary with recommendation=GO and input_qa_failures=0.")
    if len(results) != 45000 or results["profile_id"].nunique() != 45000:
        raise RuntimeError("Expected 45,000 unique result profiles.")
    if not results["status"].eq("ok").all():
        raise RuntimeError("All profiles must have status=ok for Phase 5.2.")
    if len(pf) != 45000 or not pf[["weather_pass", "sowing_pass", "n_pass", "co2_pass"]].astype(bool).all().all():
        raise RuntimeError("Repaired QA pass/fail table is not fully passing.")

    records = []
    for i, (_, row) in enumerate(results.iterrows(), start=1):
        daily = read_daily_for_row(row, root)
        records.append(build_feature_row(row, daily))
        if i % 5000 == 0:
            print(f"processed {i}/45000 profiles", flush=True)

    feature_table = pd.DataFrame(records)
    qa = {
        "rows": int(len(feature_table)),
        "unique_profile_ids": int(feature_table["meta__profile_id"].nunique()),
        "duplicate_profile_ids": int(feature_table["meta__profile_id"].duplicated().sum()),
        "target_counts": feature_table["target__model"].value_counts().to_dict(),
        "wofost_non_maturity_count": int(feature_table["feature__state_wofost_non_maturity"].sum()),
        "wofost_zero_yield_count": int(feature_table["feature__state_wofost_zero_yield"].sum()),
        "apsim_short_daily_raw_count": int(
            ((feature_table["target__model"].eq("APSIM")) & (feature_table["meta__daily_raw_row_count"].eq(300))).sum()
        ),
        "allowed_classifier_feature_count": int(sum(is_allowed_classifier_feature(c) for c in feature_table.columns)),
    }
    return feature_table, qa


def write_report(
    root: Path,
    feature_table: pd.DataFrame,
    dictionary: pd.DataFrame,
    missingness: pd.DataFrame,
    leakage: pd.DataFrame,
    qa: dict[str, Any],
) -> None:
    paths = output_paths(root)
    feature_cols = dictionary[dictionary["allowed_for_classifier"]]["column"].tolist()
    missing_feature_rows = missingness[(missingness["allowed_for_classifier"]) & (missingness["missing_count"] > 0)]
    non_maturity = int(feature_table["feature__state_wofost_non_maturity"].sum())
    zero_yield = int(feature_table["feature__state_wofost_zero_yield"].sum())
    endpoint_maturity_missing = int(feature_table["feature__endpoint_maturity_doy"].isna().sum())
    report = f"""# Phase 5.2 Feature Engineering Report

Date: 2026-07-02

Result package:

`{root}`

Phase gate: **Phase 5.2 complete. Stop here and wait for approval before Phase 5.3 Classifier.**

Final recommendation for Phase 5.3: **GO**

## 1. Input Files Used

- `reports/full_simulation_results.csv`
- `reports/full_simulation_summary.json`
- `qa/full_simulation_input_qa_pass_fail.csv`
- `qa/full_simulation_qa_repair_statistics.json`
- `reports/43_QA_SUMMARY_REPAIR_REPORT.md`
- `outputs/apsim/daily/*.csv`
- `outputs/wofost/daily/*.csv`

No raw simulation outputs were modified.

## 2. Generated Outputs

- `features/full_simulation_feature_table.csv`
- `features/full_simulation_feature_dictionary.csv`
- `features/full_simulation_missingness_report.csv`
- `features/full_simulation_leakage_audit.csv`
- `features/full_simulation_feature_qa.json`
- `reports/44_FEATURE_ENGINEERING_REPORT.md`

## 3. Feature Construction Logic

The feature table has one row per simulation profile. The target is retained as `target__model` and `target__model_binary`, but target columns are not allowed classifier input features.

Column prefixes define use:

- `meta__`: identifiers or audit metadata; retained for joins and QA, not classifier inputs.
- `target__`: classifier label columns; never classifier inputs.
- `feature__`: candidate classifier features, subject to the dictionary's `allowed_for_classifier` flag.

Feature groups:

- Design/perturbation features: year, sowing DOY, N rate, perturbation family/factor/level, radiation, temperature, water, N, CO2, and sowing perturbation settings.
- Endpoint features: yield, max LAI, max biomass, flowering DOY, maturity DOY, and harvest index.
- State features: maturity observed, non-maturity, zero yield, WOFOST non-maturity, and WOFOST zero yield.
- Daily features: mapped common crop-state summaries for LAI, aboveground biomass/TAGP, and grain/WSO.

Common cross-model unavailable fields such as APSIM `nfix_total = unavailable` are excluded from classifier features.

## 4. Daily Feature-Window Rule

Rule code:

`sowing_to_maturity_else_observed_end`

For each profile:

1. Start at `adjusted_sowing_date`.
2. If maturity DOY is present, end at maturity date.
3. If maturity DOY is missing, end at the last observed daily row.
4. If a maturity date extends beyond the observed daily file, cap at the observed end and flag `feature__daily_window_ended_at_observed_end = 1`.
5. Daily blanks are not imputed. Summaries use observed numeric crop-state values and companion observed/missing-day counts.

This handles APSIM short daily sequences consistently without padding and handles WOFOST variable-length/non-maturity sequences without deleting profiles.

## 5. Non-Maturity Encoding

Non-maturity is retained, not deleted.

Encoded columns:

- `feature__state_maturity_observed`
- `feature__state_non_maturity`
- `feature__state_wofost_non_maturity`
- `feature__endpoint_maturity_doy`
- `feature__daily_window_used_maturity`
- `feature__daily_window_ended_at_observed_end`

Counts:

- WOFOST non-maturity profiles retained: {non_maturity}
- Missing endpoint maturity values retained: {endpoint_maturity_missing}

## 6. Zero-Yield Handling

Zero-yield profiles are retained as real stress outcomes, not failures.

Encoded columns:

- `feature__state_zero_yield`
- `feature__state_wofost_zero_yield`
- `feature__endpoint_yield`
- `feature__endpoint_harvest_index`

WOFOST zero-yield profiles retained: {zero_yield}

## 7. Excluded Fields and Reasons

Main exclusions:

- `model`: direct target label; represented only as target columns.
- `profile_id`: includes model prefix and can directly leak target.
- paths, hashes, status, runtime, worker PID, attempt: technical metadata, not scientific features.
- `nfix_total`: APSIM unavailable and WOFOST-specific; excluded from common cross-model feature set.
- `reported_co2_values`: APSIM endpoint-only and duplicate of design CO2; excluded as common feature.
- `cumulative_et`, `cumulative_transpiration`, `cumulative_n_uptake`: WOFOST endpoint-only in this package; excluded from common feature set.
- raw daily-file row count/last DOY: retained as `meta__` audit fields, excluded from classifier inputs.

Full audit is in `features/full_simulation_leakage_audit.csv`.

## 8. Missingness Summary

Feature table row count: {len(feature_table)}

Columns in feature table: {len(feature_table.columns)}

Allowed classifier feature columns: {len(feature_cols)}

Allowed classifier features with missing values: {len(missing_feature_rows)}

Primary missingness is intentional:

- `feature__endpoint_maturity_doy` has missing values for WOFOST non-maturity and is paired with explicit state flags.
- Daily summaries do not silently impute all-missing mapped source values.

Full missingness table is in `features/full_simulation_missingness_report.csv`.

## 9. Leakage Audit

Target and metadata columns are retained but excluded from classifier inputs.

Classifier phases should select only dictionary rows where:

`allowed_for_classifier = True`

This excludes:

- `target__model`
- `target__model_binary`
- all `meta__` columns
- model/path/hash/runtime/status fields
- model-specific unavailable endpoint fields

Full leakage audit is in `features/full_simulation_leakage_audit.csv`.

## 10. Final Row Count and Profile ID Checks

| Check | Value |
|---|---:|
| Feature rows | {qa['rows']} |
| Unique profile IDs | {qa['unique_profile_ids']} |
| Duplicate profile IDs | {qa['duplicate_profile_ids']} |
| APSIM rows | {qa['target_counts'].get('APSIM', 0)} |
| WOFOST rows | {qa['target_counts'].get('WOFOST', 0)} |
| WOFOST non-maturity retained | {qa['wofost_non_maturity_count']} |
| WOFOST zero-yield retained | {qa['wofost_zero_yield_count']} |
| APSIM 300-row daily files retained | {qa['apsim_short_daily_raw_count']} |

## 11. Recommendation for Phase 5.3

**GO**

The Phase 5.2 feature table is analysis-ready for the classifier stage, provided Phase 5.3 uses only columns marked `allowed_for_classifier = True` in the feature dictionary and does not start before this report is approved.

Stop here. Do not start classifier, SHAP/XAI, manuscript revision, Response Letter revision, or Supplement revision until explicit approval is given.
"""
    paths.report.write_text(report)


def main(root: Path = ROOT) -> None:
    paths = output_paths(root)
    paths.feature_table.parent.mkdir(parents=True, exist_ok=True)

    feature_table, qa = build_feature_table(root)
    dictionary = build_dictionary(feature_table)
    missingness = build_missingness_report(feature_table, dictionary)
    leakage = build_leakage_audit(
        pd.read_csv(root / "reports/full_simulation_results.csv", nrows=0).columns.tolist(),
        feature_table.columns.tolist(),
    )

    feature_table.to_csv(paths.feature_table, index=False)
    dictionary.to_csv(paths.dictionary, index=False)
    missingness.to_csv(paths.missingness, index=False)
    leakage.to_csv(paths.leakage_audit, index=False)
    paths.qa_json.write_text(json.dumps(qa, indent=2) + "\n")
    write_report(root, feature_table, dictionary, missingness, leakage, qa)

    print(json.dumps(qa, indent=2), flush=True)


if __name__ == "__main__":
    main()
