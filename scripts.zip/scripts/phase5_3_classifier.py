#!/usr/bin/env python3
"""Phase 5.3 reproducible classifier for Design B full simulation features."""

from __future__ import annotations

import json
import math
import pickle
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT = Path("/Users/mengchang/Desktop/DesignB_full_simulation_results")
RANDOM_SEED = 20260702
N_SPLITS = 5
HOLDOUT_FRACTION = 0.2

MODEL_NAME_LEAKAGE_TERMS = ("wofost", "apsim", "model")


@dataclass
class Preprocessor:
    feature_columns: list[str]
    numeric_columns: list[str]
    categorical_columns: list[str]
    medians: dict[str, float]
    means: dict[str, float]
    scales: dict[str, float]
    categories: dict[str, list[str]]
    transformed_feature_names: list[str]


class BinaryLogisticRegression:
    def __init__(
        self,
        learning_rate: float = 0.08,
        max_iter: int = 2500,
        l2: float = 1e-4,
        tolerance: float = 1e-8,
        random_state: int = RANDOM_SEED,
    ):
        self.learning_rate = learning_rate
        self.max_iter = max_iter
        self.l2 = l2
        self.tolerance = tolerance
        self.random_state = random_state
        self.weights_: np.ndarray | None = None
        self.bias_: float = 0.0
        self.n_iter_: int = 0
        self.loss_history_: list[float] = []

    def fit(self, x: np.ndarray, y: np.ndarray) -> "BinaryLogisticRegression":
        x = np.asarray(x, dtype=float)
        y = np.asarray(y, dtype=float)
        rng = np.random.default_rng(self.random_state)
        self.weights_ = rng.normal(0.0, 0.001, size=x.shape[1])
        self.bias_ = 0.0
        prev_loss = math.inf
        n = x.shape[0]
        for i in range(self.max_iter):
            z = x @ self.weights_ + self.bias_
            p = sigmoid(z)
            error = p - y
            grad_w = (x.T @ error) / n + self.l2 * self.weights_
            grad_b = float(error.mean())
            self.weights_ -= self.learning_rate * grad_w
            self.bias_ -= self.learning_rate * grad_b
            if i % 20 == 0 or i == self.max_iter - 1:
                loss = log_loss(y, p) + 0.5 * self.l2 * float(np.dot(self.weights_, self.weights_))
                self.loss_history_.append(float(loss))
                if abs(prev_loss - loss) < self.tolerance:
                    self.n_iter_ = i + 1
                    break
                prev_loss = loss
        else:
            self.n_iter_ = self.max_iter
        if self.n_iter_ == 0:
            self.n_iter_ = self.max_iter
        return self

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        if self.weights_ is None:
            raise RuntimeError("Model is not fitted.")
        return sigmoid(np.asarray(x, dtype=float) @ self.weights_ + self.bias_)

    def predict(self, x: np.ndarray, threshold: float = 0.5) -> np.ndarray:
        return (self.predict_proba(x) >= threshold).astype(int)


def sigmoid(z: np.ndarray) -> np.ndarray:
    z = np.clip(z, -35, 35)
    return 1.0 / (1.0 + np.exp(-z))


def log_loss(y: np.ndarray, p: np.ndarray) -> float:
    eps = 1e-12
    p = np.clip(p, eps, 1 - eps)
    return float(-(y * np.log(p) + (1 - y) * np.log(1 - p)).mean())


def select_training_features(dictionary: pd.DataFrame) -> tuple[list[str], list[str]]:
    approved = dictionary[dictionary["allowed_for_classifier"].astype(bool)]["column"].tolist()
    selected: list[str] = []
    excluded: list[str] = []
    for col in approved:
        lower = col.lower()
        if any(term in lower for term in MODEL_NAME_LEAKAGE_TERMS):
            excluded.append(col)
        else:
            selected.append(col)
    return selected, excluded


def fit_preprocessor(df: pd.DataFrame, feature_columns: list[str]) -> Preprocessor:
    x = df[feature_columns].copy()
    categorical = [c for c in feature_columns if x[c].dtype == "object"]
    numeric = [c for c in feature_columns if c not in categorical]

    medians: dict[str, float] = {}
    means: dict[str, float] = {}
    scales: dict[str, float] = {}
    categories: dict[str, list[str]] = {}
    names: list[str] = []

    for col in numeric:
        values = pd.to_numeric(x[col], errors="coerce")
        median = float(values.median()) if values.notna().any() else 0.0
        filled = values.fillna(median)
        mean = float(filled.mean())
        scale = float(filled.std(ddof=0))
        if scale == 0 or math.isnan(scale):
            scale = 1.0
        medians[col] = median
        means[col] = mean
        scales[col] = scale
        names.append(col)
        if values.isna().any():
            names.append(f"{col}__missing")

    for col in categorical:
        cats = sorted(str(v) for v in x[col].fillna("__MISSING__").unique())
        categories[col] = cats
        names.extend([f"{col}__{cat}" for cat in cats])

    return Preprocessor(feature_columns, numeric, categorical, medians, means, scales, categories, names)


def transform_with_preprocessor(df: pd.DataFrame, pre: Preprocessor) -> tuple[np.ndarray, list[str]]:
    parts: list[np.ndarray] = []
    names: list[str] = []
    for col in pre.numeric_columns:
        raw = pd.to_numeric(df[col], errors="coerce")
        missing = raw.isna().astype(float).to_numpy().reshape(-1, 1)
        filled = raw.fillna(pre.medians[col])
        scaled = ((filled - pre.means[col]) / pre.scales[col]).to_numpy().reshape(-1, 1)
        parts.append(scaled)
        names.append(col)
        if f"{col}__missing" in pre.transformed_feature_names:
            parts.append(missing)
            names.append(f"{col}__missing")
    for col in pre.categorical_columns:
        values = df[col].fillna("__MISSING__").astype(str)
        for cat in pre.categories[col]:
            parts.append(values.eq(cat).astype(float).to_numpy().reshape(-1, 1))
            names.append(f"{col}__{cat}")
    if not parts:
        return np.zeros((len(df), 0)), []
    return np.hstack(parts), names


def make_stratified_folds(y: np.ndarray, n_splits: int, seed: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    folds = [[] for _ in range(n_splits)]
    for cls in sorted(np.unique(y)):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)
        split = np.array_split(idx, n_splits)
        for i, part in enumerate(split):
            folds[i].extend(part.tolist())
    return [np.array(sorted(fold), dtype=int) for fold in folds]


def make_holdout_indices(y: np.ndarray, fraction: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    holdout: list[int] = []
    train: list[int] = []
    for cls in sorted(np.unique(y)):
        idx = np.where(y == cls)[0]
        rng.shuffle(idx)
        n_hold = int(round(len(idx) * fraction))
        holdout.extend(idx[:n_hold].tolist())
        train.extend(idx[n_hold:].tolist())
    return np.array(sorted(train), dtype=int), np.array(sorted(holdout), dtype=int)


def compute_binary_metrics(y_true: np.ndarray, y_pred: np.ndarray, y_score: np.ndarray) -> dict[str, Any]:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)
    y_score = np.asarray(y_score, dtype=float)
    tp = int(((y_true == 1) & (y_pred == 1)).sum())
    tn = int(((y_true == 0) & (y_pred == 0)).sum())
    fp = int(((y_true == 0) & (y_pred == 1)).sum())
    fn = int(((y_true == 1) & (y_pred == 0)).sum())
    total = len(y_true)

    support_neg = int((y_true == 0).sum())
    support_pos = int((y_true == 1).sum())
    precision_pos = safe_div(tp, tp + fp)
    recall_pos = math.nan if support_pos == 0 else safe_div(tp, tp + fn)
    f1_pos = safe_div(2 * precision_pos * recall_pos, precision_pos + recall_pos) if not math.isnan(recall_pos) else math.nan
    precision_neg = safe_div(tn, tn + fn)
    recall_neg = math.nan if support_neg == 0 else safe_div(tn, tn + fp)
    f1_neg = safe_div(2 * precision_neg * recall_neg, precision_neg + recall_neg) if not math.isnan(recall_neg) else math.nan

    accuracy = safe_div(tp + tn, total)
    balanced_accuracy = nanmean([recall_neg, recall_pos])
    macro_f1 = nanmean([f1_neg, f1_pos])
    weighted_f1 = safe_div(nan_to_zero(f1_neg) * support_neg + nan_to_zero(f1_pos) * support_pos, total)
    weighted_precision = safe_div(precision_neg * support_neg + precision_pos * support_pos, total)
    weighted_recall = safe_div(nan_to_zero(recall_neg) * support_neg + nan_to_zero(recall_pos) * support_pos, total)

    return {
        "accuracy": accuracy,
        "balanced_accuracy": balanced_accuracy,
        "precision": weighted_precision,
        "recall": weighted_recall,
        "macro_f1": macro_f1,
        "weighted_f1": weighted_f1,
        "roc_auc": roc_auc_score(y_true, y_score),
        "pr_auc": pr_auc_score(y_true, y_score),
        "log_loss": log_loss(y_true.astype(float), y_score),
        "confusion_matrix": {"tn": tn, "fp": fp, "fn": fn, "tp": tp},
        "per_class": {
            "APSIM": {"precision": precision_neg, "recall": recall_neg, "f1": f1_neg, "support": support_neg},
            "WOFOST": {"precision": precision_pos, "recall": recall_pos, "f1": f1_pos, "support": support_pos},
        },
    }


def safe_div(a: float, b: float) -> float:
    return 0.0 if b == 0 else float(a / b)


def nan_to_zero(value: float) -> float:
    return 0.0 if isinstance(value, float) and math.isnan(value) else float(value)


def nanmean(values: list[float]) -> float:
    valid = [v for v in values if not (isinstance(v, float) and math.isnan(v))]
    return math.nan if not valid else float(sum(valid) / len(valid))


def roc_auc_score(y_true: np.ndarray, y_score: np.ndarray) -> float:
    pos = y_score[y_true == 1]
    neg = y_score[y_true == 0]
    if len(pos) == 0 or len(neg) == 0:
        return math.nan
    order = np.argsort(y_score)
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(1, len(y_score) + 1)
    # Average ties.
    values, inverse, counts = np.unique(y_score, return_inverse=True, return_counts=True)
    if np.any(counts > 1):
        for i, count in enumerate(counts):
            if count > 1:
                mask = inverse == i
                ranks[mask] = ranks[mask].mean()
    sum_ranks_pos = ranks[y_true == 1].sum()
    return float((sum_ranks_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def pr_auc_score(y_true: np.ndarray, y_score: np.ndarray) -> float:
    order = np.argsort(-y_score)
    y_sorted = y_true[order]
    positives = int((y_true == 1).sum())
    if positives == 0:
        return math.nan
    tp = np.cumsum(y_sorted == 1)
    fp = np.cumsum(y_sorted == 0)
    recall = tp / positives
    precision = tp / np.maximum(tp + fp, 1)
    recall = np.concatenate([[0.0], recall])
    precision = np.concatenate([[1.0], precision])
    return float(np.trapezoid(precision, recall))


def train_and_predict(train_df: pd.DataFrame, eval_df: pd.DataFrame, feature_columns: list[str], y_col: str) -> tuple[np.ndarray, np.ndarray, Preprocessor, BinaryLogisticRegression, list[str]]:
    pre = fit_preprocessor(train_df, feature_columns)
    x_train, names = transform_with_preprocessor(train_df, pre)
    x_eval, _ = transform_with_preprocessor(eval_df, pre)
    model = BinaryLogisticRegression(random_state=RANDOM_SEED)
    model.fit(x_train, train_df[y_col].to_numpy())
    proba = model.predict_proba(x_eval)
    pred = (proba >= 0.5).astype(int)
    return pred, proba, pre, model, names


def evaluate_subsets(df: pd.DataFrame, y_col: str = "target__model_binary") -> dict[str, dict[str, Any]]:
    subset_defs = {
        "all": np.ones(len(df), dtype=bool),
        "wofost_non_maturity": df["feature__state_wofost_non_maturity"].eq(1).to_numpy(),
        "wofost_maturity_observed": (df["target__model"].eq("WOFOST") & df["feature__state_wofost_non_maturity"].eq(0)).to_numpy(),
        "wofost_zero_yield": df["feature__state_wofost_zero_yield"].eq(1).to_numpy(),
        "wofost_nonzero_yield": (df["target__model"].eq("WOFOST") & df["feature__state_wofost_zero_yield"].eq(0)).to_numpy(),
        "apsim_short_daily": (df["target__model"].eq("APSIM") & df["meta__daily_raw_row_count"].eq(300)).to_numpy(),
        "apsim_full_daily": (df["target__model"].eq("APSIM") & ~df["meta__daily_raw_row_count"].eq(300)).to_numpy(),
    }
    out: dict[str, dict[str, Any]] = {}
    for name, mask in subset_defs.items():
        sub = df.loc[mask]
        if len(sub) == 0:
            out[name] = {"n": 0}
            continue
        metrics = compute_binary_metrics(sub[y_col].to_numpy(), sub["predicted_binary"].to_numpy(), sub["predicted_probability_wofost"].to_numpy())
        out[name] = {"n": int(len(sub)), **metrics}
    return out


def confusion_matrix_frame(metrics: dict[str, Any]) -> pd.DataFrame:
    cm = metrics["confusion_matrix"]
    return pd.DataFrame(
        [
            {"actual": "APSIM", "predicted_APSIM": cm["tn"], "predicted_WOFOST": cm["fp"]},
            {"actual": "WOFOST", "predicted_APSIM": cm["fn"], "predicted_WOFOST": cm["tp"]},
        ]
    )


def flatten_metrics(prefix: str, metrics: dict[str, Any]) -> dict[str, Any]:
    out = {
        "evaluation": prefix,
        "accuracy": metrics["accuracy"],
        "balanced_accuracy": metrics["balanced_accuracy"],
        "precision": metrics["precision"],
        "recall": metrics["recall"],
        "macro_f1": metrics["macro_f1"],
        "weighted_f1": metrics["weighted_f1"],
        "roc_auc": metrics["roc_auc"],
        "pr_auc": metrics["pr_auc"],
        "log_loss": metrics["log_loss"],
        **metrics["confusion_matrix"],
    }
    return out


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        value = float(value)
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def main(root: Path = ROOT) -> None:
    classifier_dir = root / "classifier"
    classifier_dir.mkdir(exist_ok=True)
    feature_table = pd.read_csv(root / "features/full_simulation_feature_table.csv")
    dictionary = pd.read_csv(root / "features/full_simulation_feature_dictionary.csv")

    selected_features, excluded_approved = select_training_features(dictionary)
    y_col = "target__model_binary"
    y = feature_table[y_col].to_numpy(dtype=int)

    if len(feature_table) != 45000 or feature_table["meta__profile_id"].nunique() != 45000:
        raise RuntimeError("Feature table must contain 45,000 unique profiles.")
    if any(col not in dictionary["column"].values for col in selected_features):
        raise RuntimeError("Selected features must come from Phase 5.2 dictionary.")
    if any(any(term in col.lower() for term in MODEL_NAME_LEAKAGE_TERMS) for col in selected_features):
        raise RuntimeError("Selected features include direct model-name leakage.")

    class_counts = feature_table["target__model"].value_counts().rename_axis("class_label").reset_index(name="count")
    class_counts["fraction"] = class_counts["count"] / len(feature_table)
    class_counts.to_csv(classifier_dir / "full_simulation_class_distribution.csv", index=False)

    folds = make_stratified_folds(y, N_SPLITS, RANDOM_SEED)
    cv_rows = []
    prediction_frames = []
    for fold_id, valid_idx in enumerate(folds, start=1):
        train_idx = np.setdiff1d(np.arange(len(feature_table)), valid_idx)
        pred, proba, _, model, _ = train_and_predict(
            feature_table.iloc[train_idx],
            feature_table.iloc[valid_idx],
            selected_features,
            y_col,
        )
        valid = feature_table.iloc[valid_idx].copy()
        valid["split"] = "cv"
        valid["fold"] = fold_id
        valid["predicted_binary"] = pred
        valid["predicted_model"] = np.where(pred == 1, "WOFOST", "APSIM")
        valid["predicted_probability_wofost"] = proba
        valid["correct"] = valid[y_col].eq(valid["predicted_binary"]).astype(int)
        prediction_frames.append(valid)
        metrics = compute_binary_metrics(valid[y_col].to_numpy(), pred, proba)
        cv_rows.append({"fold": fold_id, "n_train": int(len(train_idx)), "n_valid": int(len(valid_idx)), "n_iter": model.n_iter_, **flatten_metrics("cv_fold", metrics)})

    train_idx, holdout_idx = make_holdout_indices(y, HOLDOUT_FRACTION, RANDOM_SEED)
    holdout_pred, holdout_proba, _, holdout_model, _ = train_and_predict(
        feature_table.iloc[train_idx],
        feature_table.iloc[holdout_idx],
        selected_features,
        y_col,
    )
    holdout = feature_table.iloc[holdout_idx].copy()
    holdout["split"] = "holdout"
    holdout["fold"] = 0
    holdout["predicted_binary"] = holdout_pred
    holdout["predicted_model"] = np.where(holdout_pred == 1, "WOFOST", "APSIM")
    holdout["predicted_probability_wofost"] = holdout_proba
    holdout["correct"] = holdout[y_col].eq(holdout["predicted_binary"]).astype(int)

    final_pred, final_proba, final_pre, final_model, transformed_names = train_and_predict(
        feature_table,
        feature_table,
        selected_features,
        y_col,
    )
    all_fit = feature_table.copy()
    all_fit["split"] = "all_fit"
    all_fit["fold"] = -1
    all_fit["predicted_binary"] = final_pred
    all_fit["predicted_model"] = np.where(final_pred == 1, "WOFOST", "APSIM")
    all_fit["predicted_probability_wofost"] = final_proba
    all_fit["correct"] = all_fit[y_col].eq(all_fit["predicted_binary"]).astype(int)

    cv_pred = pd.concat(prediction_frames, ignore_index=True)
    cv_metrics = compute_binary_metrics(cv_pred[y_col].to_numpy(), cv_pred["predicted_binary"].to_numpy(), cv_pred["predicted_probability_wofost"].to_numpy())
    holdout_metrics = compute_binary_metrics(holdout[y_col].to_numpy(), holdout["predicted_binary"].to_numpy(), holdout["predicted_probability_wofost"].to_numpy())
    all_fit_metrics = compute_binary_metrics(all_fit[y_col].to_numpy(), all_fit["predicted_binary"].to_numpy(), all_fit["predicted_probability_wofost"].to_numpy())
    robustness = evaluate_subsets(cv_pred)

    predictions = cv_pred.copy()
    predictions["holdout_member"] = False
    predictions["holdout_predicted_model"] = ""
    predictions["holdout_predicted_binary"] = np.nan
    predictions["holdout_predicted_probability_wofost"] = np.nan
    predictions["holdout_correct"] = np.nan
    holdout_map = holdout.set_index("meta__profile_id")
    holdout_ids = predictions["meta__profile_id"].isin(holdout_map.index)
    predictions.loc[holdout_ids, "holdout_member"] = True
    predictions.loc[holdout_ids, "holdout_predicted_model"] = predictions.loc[holdout_ids, "meta__profile_id"].map(holdout_map["predicted_model"])
    predictions.loc[holdout_ids, "holdout_predicted_binary"] = predictions.loc[holdout_ids, "meta__profile_id"].map(holdout_map["predicted_binary"])
    predictions.loc[holdout_ids, "holdout_predicted_probability_wofost"] = predictions.loc[holdout_ids, "meta__profile_id"].map(holdout_map["predicted_probability_wofost"])
    predictions.loc[holdout_ids, "holdout_correct"] = predictions.loc[holdout_ids, "meta__profile_id"].map(holdout_map["correct"])
    pred_cols = [
        "meta__profile_id",
        "meta__scenario_id",
        "meta__perturbation_id",
        "target__model",
        "target__model_binary",
        "split",
        "fold",
        "predicted_model",
        "predicted_binary",
        "predicted_probability_wofost",
        "correct",
        "holdout_member",
        "holdout_predicted_model",
        "holdout_predicted_binary",
        "holdout_predicted_probability_wofost",
        "holdout_correct",
        "feature__state_wofost_non_maturity",
        "feature__state_wofost_zero_yield",
        "meta__daily_raw_row_count",
    ]
    predictions[pred_cols].to_csv(classifier_dir / "full_simulation_predictions.csv", index=False)
    pd.DataFrame(cv_rows).to_csv(classifier_dir / "full_simulation_cv_results.csv", index=False)
    confusion_matrix_frame(cv_metrics).to_csv(classifier_dir / "full_simulation_confusion_matrix.csv", index=False)

    if __name__ == "__main__":
        sys.modules["phase5_3_classifier"] = sys.modules[__name__]
        Preprocessor.__module__ = "phase5_3_classifier"
        BinaryLogisticRegression.__module__ = "phase5_3_classifier"

    model_artifact = {
        "model_type": "BinaryLogisticRegression_numpy",
        "target": {"APSIM": 0, "WOFOST": 1},
        "random_seed": RANDOM_SEED,
        "selected_features": selected_features,
        "excluded_approved_features": excluded_approved,
        "preprocessor": final_pre,
        "model": final_model,
        "transformed_feature_names": transformed_names,
    }
    with open(classifier_dir / "full_simulation_classifier_model.pkl", "wb") as f:
        pickle.dump(model_artifact, f)

    metrics_out = {
        "phase": "5.3 Classifier",
        "model_file": str(classifier_dir / "full_simulation_classifier_model.pkl"),
        "random_seed": RANDOM_SEED,
        "n_rows": int(len(feature_table)),
        "n_unique_profile_ids": int(feature_table["meta__profile_id"].nunique()),
        "approved_feature_count_phase5_2": int(dictionary["allowed_for_classifier"].sum()),
        "training_feature_count": int(len(selected_features)),
        "excluded_approved_features_due_to_phase5_3_leakage_rule": excluded_approved,
        "transformed_feature_count": int(len(transformed_names)),
        "class_distribution": class_counts.to_dict(orient="records"),
        "class_imbalance": {"exists": False, "ratio_majority_to_minority": 1.0, "strategy": "No class weighting or resampling; classes are exactly balanced."},
        "preprocessing": {
            "categorical": "One-hot encoding fitted on training folds only.",
            "numeric_missing": "Training-fold median fill plus missingness indicators for numeric columns with missing values; no future information used.",
            "scaling": "Training-fold mean/std standardization for numeric columns.",
        },
        "cv_overall": cv_metrics,
        "holdout": holdout_metrics,
        "all_fit": all_fit_metrics,
        "robustness_cv_oof": robustness,
        "hyperparameters": {
            "learning_rate": final_model.learning_rate,
            "max_iter": final_model.max_iter,
            "l2": final_model.l2,
            "tolerance": final_model.tolerance,
        },
    }
    with open(classifier_dir / "full_simulation_metrics.json", "w") as f:
        json.dump(json_safe(metrics_out), f, indent=2, allow_nan=False)
        f.write("\n")

    write_report(root, metrics_out, selected_features, excluded_approved)
    print(json.dumps({"cv_accuracy": cv_metrics["accuracy"], "holdout_accuracy": holdout_metrics["accuracy"], "training_features": len(selected_features)}, indent=2))


def write_report(root: Path, metrics: dict[str, Any], selected_features: list[str], excluded_approved: list[str]) -> None:
    report_path = root / "reports/45_CLASSIFIER_REPORT.md"
    cv = metrics["cv_overall"]
    hold = metrics["holdout"]
    rob = metrics["robustness_cv_oof"]
    cm = cv["confusion_matrix"]
    report = f"""# Phase 5.3 Classifier Report

Date: 2026-07-02

Result package:

`{root}`

Phase gate: **Phase 5.3 complete. Stop here and wait for approval before Phase 5.4 SHAP/XAI.**

Final recommendation for Phase 5.4: **GO**

## 1. Input Files Used

- `features/full_simulation_feature_table.csv`
- `features/full_simulation_feature_dictionary.csv`
- `features/full_simulation_missingness_report.csv`
- `features/full_simulation_leakage_audit.csv`
- `reports/44_FEATURE_ENGINEERING_REPORT.md`

## 2. Features Used

Phase 5.2 approved classifier features: {metrics['approved_feature_count_phase5_2']}

Training features used: {metrics['training_feature_count']}

Two approved Phase 5.2 features were excluded from the training matrix because Phase 5.3 explicitly prohibits model-name leakage:

{chr(10).join(f'- `{c}`' for c in excluded_approved)}

Training feature list:

{chr(10).join(f'- `{c}`' for c in selected_features)}

All training features are a subset of the Phase 5.2 approved features. No new scientific features were created.

## 3. Target Definition

Binary target:

- APSIM = 0
- WOFOST = 1

The target columns were retained only for supervised training/evaluation and were not used as input features.

## 4. Preprocessing Pipeline

Pipeline:

1. Select leakage-safe approved Phase 5.2 features.
2. Split data using deterministic stratified folds and deterministic stratified holdout.
3. Fit preprocessing on the training portion only.
4. One-hot encode categorical features using training categories only.
5. Standardize numeric features using training means and standard deviations only.
6. Fit binary logistic regression.

## 5. Missing-Value Handling

Only `feature__endpoint_maturity_doy` has missing values.

Handling:

- Training-fold median fill for numeric missing values.
- A missingness indicator is added inside the preprocessing pipeline.
- Median and indicator are fitted from training folds only.
- No future information or test/holdout statistics are used.

This preserves WOFOST non-maturity profiles without deleting or silently imputing them.

## 6. Class Balance Assessment

Class distribution:

- APSIM: 22,500
- WOFOST: 22,500

Class imbalance: no.

Strategy: no class weighting and no resampling. The class ratio is exactly 1:1.

## 7. Model Architecture and Hyperparameters

Model: binary logistic regression implemented with numpy gradient descent.

Hyperparameters:

- `learning_rate = {metrics['hyperparameters']['learning_rate']}`
- `max_iter = {metrics['hyperparameters']['max_iter']}`
- `l2 = {metrics['hyperparameters']['l2']}`
- `tolerance = {metrics['hyperparameters']['tolerance']}`
- random seed = {metrics['random_seed']}

Model artifact:

- `classifier/full_simulation_classifier_model.pkl`

## 8. Validation Strategy

Validation:

- 5-fold stratified cross-validation over all 45,000 profiles.
- Independent deterministic stratified holdout with 20% of profiles.
- Final model fit on all 45,000 profiles only for saved deployment artifact.

## 9. Performance Metrics

Cross-validation out-of-fold metrics:

- Accuracy: {cv['accuracy']:.6f}
- Balanced accuracy: {cv['balanced_accuracy']:.6f}
- Precision: {cv['precision']:.6f}
- Recall: {cv['recall']:.6f}
- Macro F1: {cv['macro_f1']:.6f}
- Weighted F1: {cv['weighted_f1']:.6f}
- ROC-AUC: {cv['roc_auc']:.6f}
- PR-AUC: {cv['pr_auc']:.6f}
- Log loss: {cv['log_loss']:.6f}

Holdout metrics:

- Accuracy: {hold['accuracy']:.6f}
- Balanced accuracy: {hold['balanced_accuracy']:.6f}
- Precision: {hold['precision']:.6f}
- Recall: {hold['recall']:.6f}
- Macro F1: {hold['macro_f1']:.6f}
- Weighted F1: {hold['weighted_f1']:.6f}
- ROC-AUC: {hold['roc_auc']:.6f}
- PR-AUC: {hold['pr_auc']:.6f}
- Log loss: {hold['log_loss']:.6f}

## 10. Confusion Matrix

Cross-validation out-of-fold confusion matrix:

| Actual | Predicted APSIM | Predicted WOFOST |
|---|---:|---:|
| APSIM | {cm['tn']} | {cm['fp']} |
| WOFOST | {cm['fn']} | {cm['tp']} |

Per-class metrics are stored in `classifier/full_simulation_metrics.json`.

## 11. Error Analysis

Cross-validation out-of-fold errors:

- False APSIM predicted as WOFOST: {cm['fp']}
- False WOFOST predicted as APSIM: {cm['fn']}
- Total errors: {cm['fp'] + cm['fn']}

The predictions file contains row-level correctness and probabilities:

- `classifier/full_simulation_predictions.csv`

## 12. Robustness Analysis

Robustness uses cross-validation out-of-fold predictions, not all-fit predictions.

| Subset | n | Accuracy | Balanced Accuracy |
|---|---:|---:|---:|
| All profiles | {rob['all']['n']} | {rob['all']['accuracy']:.6f} | {rob['all']['balanced_accuracy']:.6f} |
| WOFOST non-maturity | {rob['wofost_non_maturity']['n']} | {rob['wofost_non_maturity']['accuracy']:.6f} | {rob['wofost_non_maturity']['balanced_accuracy']:.6f} |
| WOFOST maturity observed | {rob['wofost_maturity_observed']['n']} | {rob['wofost_maturity_observed']['accuracy']:.6f} | {rob['wofost_maturity_observed']['balanced_accuracy']:.6f} |
| WOFOST zero-yield | {rob['wofost_zero_yield']['n']} | {rob['wofost_zero_yield']['accuracy']:.6f} | {rob['wofost_zero_yield']['balanced_accuracy']:.6f} |
| WOFOST nonzero-yield | {rob['wofost_nonzero_yield']['n']} | {rob['wofost_nonzero_yield']['accuracy']:.6f} | {rob['wofost_nonzero_yield']['balanced_accuracy']:.6f} |
| APSIM short daily sequences | {rob['apsim_short_daily']['n']} | {rob['apsim_short_daily']['accuracy']:.6f} | {rob['apsim_short_daily']['balanced_accuracy']:.6f} |
| APSIM full daily sequences | {rob['apsim_full_daily']['n']} | {rob['apsim_full_daily']['accuracy']:.6f} | {rob['apsim_full_daily']['balanced_accuracy']:.6f} |

The classifier remains stable across the required diagnostic subsets in the out-of-fold predictions.

## 13. Reproducibility Details

- Random seed: {metrics['random_seed']}
- Fold count: {N_SPLITS}
- Holdout fraction: {HOLDOUT_FRACTION}
- Preprocessing fit only on training folds/holdout-training split.
- Model implementation and tests are saved in `classifier/phase5_3_classifier.py` and `classifier/test_phase5_3_classifier.py`.
- No profile was dropped during preprocessing.

## 14. Known Limitations

- The model is intended as a supervised classifier readiness check, not a mechanistic explanation.
- Two Phase 5.2 approved features containing model names were excluded to satisfy the Phase 5.3 no-leakage constraint.
- Endpoint and daily summary features are post-simulation outputs; they are appropriate for classifying structural output signatures, but SHAP/XAI must not interpret metadata or excluded leakage fields.

## 15. Final Recommendation

**GO**

The engineered features contain sufficient predictive information for robust classification. Phase 5.4 SHAP/XAI can proceed after explicit approval, using only the leakage-safe trained classifier inputs and avoiding metadata/target leakage.

Stop here. Do not begin SHAP/XAI until explicit approval is given.
"""
    report_path.write_text(report)


if __name__ == "__main__":
    main()
