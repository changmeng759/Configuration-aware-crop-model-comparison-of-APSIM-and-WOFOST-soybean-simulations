#!/usr/bin/env python3
"""Phase 5.4 leakage-safe XAI for the Design B classifier.

The Phase 5.3 classifier is a linear logistic regression trained after a
deterministic preprocessing step.  SHAP is not available in the local runtime,
so this script computes the exact additive linear attribution on the WOFOST
logit scale:

    contribution_j = beta_j * (x_j - E[x_j])

Transformed one-hot and missingness-indicator contributions are then summed back
to the original 44 leakage-safe Phase 5.3 feature names.
"""

from __future__ import annotations

import csv
import json
import math
import pickle
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd


ROOT = Path("/Users/mengchang/Desktop/DesignB_full_simulation_results")
RANDOM_SEED = 20260702
EXCLUDED_XAI_FEATURES = {
    "feature__state_wofost_non_maturity",
    "feature__state_wofost_zero_yield",
}


def load_phase53_model(root: Path) -> dict[str, Any]:
    classifier_dir = root / "classifier"
    if str(classifier_dir) not in sys.path:
        sys.path.insert(0, str(classifier_dir))
    with open(classifier_dir / "full_simulation_classifier_model.pkl", "rb") as f:
        artifact = pickle.load(f)
    return artifact


def transformed_source_feature(transformed_name: str, feature_columns: list[str]) -> str:
    if transformed_name in feature_columns:
        return transformed_name
    matches = [col for col in feature_columns if transformed_name.startswith(f"{col}__")]
    if not matches:
        raise ValueError(f"Cannot map transformed feature {transformed_name!r} to an original feature.")
    return max(matches, key=len)


def transform_feature_table(feature_table: pd.DataFrame, preprocessor: Any) -> tuple[np.ndarray, list[str]]:
    # Import the exact Phase 5.3 transform function to avoid reimplementing the
    # preprocessing contract.
    from phase5_3_classifier import transform_with_preprocessor

    x, names = transform_with_preprocessor(feature_table, preprocessor)
    if names != list(preprocessor.transformed_feature_names):
        raise RuntimeError("Transformed feature names differ from the Phase 5.3 model artifact.")
    return x, names


def compute_linear_attributions(
    x: np.ndarray,
    transformed_names: list[str],
    weights: np.ndarray,
    bias: float,
    source_features: list[str],
) -> tuple[pd.DataFrame, dict[str, float]]:
    baseline = x.mean(axis=0)
    transformed_contrib = (x - baseline) * weights.reshape(1, -1)
    expected_logit = float(bias + baseline @ weights)
    model_logit = bias + x @ weights
    shap_sum_logit = expected_logit + transformed_contrib.sum(axis=1)
    max_additivity_error = float(np.max(np.abs(model_logit - shap_sum_logit)))

    grouped = {feature: np.zeros(x.shape[0], dtype=float) for feature in source_features}
    for j, name in enumerate(transformed_names):
        source = transformed_source_feature(name, source_features)
        grouped[source] += transformed_contrib[:, j]
    shap = pd.DataFrame(grouped)
    additivity = {
        "expected_value_logit": expected_logit,
        "max_additivity_error_logit": max_additivity_error,
    }
    return shap, additivity


def feature_group(feature: str) -> str:
    if any(token in feature for token in ["weather_year", "sowing", "n_rate", "perturbation", "factor_changed", "level", "radiation", "temperature", "water_availability", "nitrogen_availability", "co2"]):
        return "weather/management perturbation"
    if "lai" in feature:
        return "LAI/canopy"
    if "biomass" in feature:
        return "biomass"
    if "grain" in feature or "harvest_index" in feature:
        return "grain/partitioning"
    if "yield" in feature or "zero_yield" in feature:
        return "yield/output"
    if any(token in feature for token in ["flowering", "maturity", "non_maturity"]):
        return "phenology"
    if any(token in feature for token in ["daily_window", "observed_days", "missing_days"]):
        return "daily-window completeness"
    return "other"


def safe_float(value: Any) -> float | None:
    try:
        value = float(value)
    except Exception:
        return None
    if math.isnan(value) or math.isinf(value):
        return None
    return value


def pearson_or_none(a: pd.Series, b: pd.Series) -> float | None:
    a = pd.to_numeric(a, errors="coerce")
    b = pd.to_numeric(b, errors="coerce")
    ok = a.notna() & b.notna()
    if ok.sum() < 3:
        return None
    av = a[ok].to_numpy(dtype=float)
    bv = b[ok].to_numpy(dtype=float)
    if np.std(av) == 0 or np.std(bv) == 0:
        return None
    return float(np.corrcoef(av, bv)[0, 1])


def rank_correlation(values_a: pd.Series, values_b: pd.Series) -> float | None:
    ranks_a = values_a.rank(method="average")
    ranks_b = values_b.rank(method="average")
    return pearson_or_none(ranks_a, ranks_b)


def summarize_global_importance(feature_table: pd.DataFrame, shap: pd.DataFrame, feature_columns: list[str]) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    is_apsim = feature_table["target__model"].eq("APSIM")
    is_wofost = feature_table["target__model"].eq("WOFOST")
    for feature in feature_columns:
        values = shap[feature]
        raw = feature_table[feature]
        corr = pearson_or_none(raw, values)
        mean_raw_apsim = safe_float(pd.to_numeric(raw[is_apsim], errors="coerce").mean())
        mean_raw_wofost = safe_float(pd.to_numeric(raw[is_wofost], errors="coerce").mean())
        mean_shap_apsim = float(values[is_apsim].mean())
        mean_shap_wofost = float(values[is_wofost].mean())
        separation = abs(mean_shap_wofost - mean_shap_apsim)
        direction = "higher values push WOFOST" if corr is not None and corr > 0 else "higher values push APSIM" if corr is not None and corr < 0 else "categorical or non-monotonic"
        role = "model-class separation" if separation > 1e-6 else "within-design modulation; not model-class separation"
        rows.append(
            {
                "feature": feature,
                "group": feature_group(feature),
                "mean_abs_shap_logit": float(values.abs().mean()),
                "mean_shap_logit": float(values.mean()),
                "mean_shap_apsim_logit": mean_shap_apsim,
                "mean_shap_wofost_logit": mean_shap_wofost,
                "class_separation_abs_logit": separation,
                "mean_raw_apsim": mean_raw_apsim,
                "mean_raw_wofost": mean_raw_wofost,
                "raw_value_shap_correlation": corr,
                "direction_summary": direction,
                "interpretation_role": role,
                "pushes_apsim_when": "negative contribution on WOFOST logit",
                "pushes_wofost_when": "positive contribution on WOFOST logit",
            }
        )
    out = pd.DataFrame(rows).sort_values(["mean_abs_shap_logit", "feature"], ascending=[False, True]).reset_index(drop=True)
    out.insert(0, "rank", np.arange(1, len(out) + 1))
    return out


def subset_masks(feature_table: pd.DataFrame) -> dict[str, pd.Series]:
    return {
        "all": pd.Series(True, index=feature_table.index),
        "wofost_non_maturity": feature_table["target__model"].eq("WOFOST") & feature_table["feature__state_wofost_non_maturity"].eq(1),
        "wofost_maturity_observed": feature_table["target__model"].eq("WOFOST") & feature_table["feature__state_wofost_non_maturity"].eq(0),
        "wofost_zero_yield": feature_table["target__model"].eq("WOFOST") & feature_table["feature__state_wofost_zero_yield"].eq(1),
        "wofost_nonzero_yield": feature_table["target__model"].eq("WOFOST") & feature_table["feature__state_wofost_zero_yield"].eq(0),
        "apsim_short_daily": feature_table["target__model"].eq("APSIM") & feature_table["meta__daily_raw_row_count"].eq(300),
        "apsim_full_daily": feature_table["target__model"].eq("APSIM") & ~feature_table["meta__daily_raw_row_count"].eq(300),
    }


def subset_audit(feature_table: pd.DataFrame, shap: pd.DataFrame, global_importance: pd.DataFrame) -> pd.DataFrame:
    masks = subset_masks(feature_table)
    global_abs = shap.abs().sum().sum()
    global_ranked = global_importance.set_index("feature")["mean_abs_shap_logit"]
    rows: list[dict[str, Any]] = []
    for name, mask in masks.items():
        n = int(mask.sum())
        if n == 0:
            rows.append({"subset": name, "n": 0})
            continue
        sub_abs = shap.loc[mask].abs()
        mean_abs = sub_abs.mean().sort_values(ascending=False)
        top_feature = mean_abs.index[0]
        rows.append(
            {
                "subset": name,
                "n": n,
                "fraction_of_profiles": n / len(feature_table),
                "total_abs_contribution_share": float(sub_abs.sum().sum() / global_abs) if global_abs else None,
                "mean_total_abs_shap_per_profile": float(sub_abs.sum(axis=1).mean()),
                "top_feature": top_feature,
                "top_feature_mean_abs_shap_logit": float(mean_abs.iloc[0]),
                "top5_feature_abs_share_within_subset": float(mean_abs.head(5).sum() / mean_abs.sum()) if mean_abs.sum() else None,
                "rank_correlation_with_global_importance": rank_correlation(mean_abs.reindex(global_ranked.index), global_ranked),
            }
        )
    return pd.DataFrame(rows)


def group_summary(global_importance: pd.DataFrame) -> pd.DataFrame:
    grouped = (
        global_importance.groupby("group", as_index=False)
        .agg(
            feature_count=("feature", "count"),
            sum_mean_abs_shap_logit=("mean_abs_shap_logit", "sum"),
            mean_mean_abs_shap_logit=("mean_abs_shap_logit", "mean"),
            sum_class_separation_abs_logit=("class_separation_abs_logit", "sum"),
        )
        .sort_values("sum_mean_abs_shap_logit", ascending=False)
        .reset_index(drop=True)
    )
    total = grouped["sum_mean_abs_shap_logit"].sum()
    grouped["share_global_importance"] = grouped["sum_mean_abs_shap_logit"] / total if total else 0.0
    separation_total = grouped["sum_class_separation_abs_logit"].sum()
    grouped["share_class_separation"] = grouped["sum_class_separation_abs_logit"] / separation_total if separation_total else 0.0
    top_features = global_importance.sort_values("mean_abs_shap_logit", ascending=False).groupby("group").first()["feature"]
    grouped["top_feature"] = grouped["group"].map(top_features)
    grouped.insert(0, "rank", np.arange(1, len(grouped) + 1))
    return grouped


def write_shap_values(
    root: Path,
    feature_table: pd.DataFrame,
    predictions: pd.DataFrame,
    shap: pd.DataFrame,
    additivity: dict[str, float],
) -> None:
    xai_dir = root / "xai"
    merged_pred = predictions.set_index("meta__profile_id")
    out = feature_table[["meta__profile_id", "target__model", "target__model_binary"]].copy()
    out["predicted_probability_wofost"] = out["meta__profile_id"].map(merged_pred["predicted_probability_wofost"])
    out["expected_value_logit"] = additivity["expected_value_logit"]
    for feature in shap.columns:
        out[f"shap__{feature}"] = shap[feature].to_numpy()
    out.to_csv(xai_dir / "full_simulation_shap_values.csv", index=False)
    np.savez_compressed(
        xai_dir / "full_simulation_shap_values.npz",
        profile_id=out["meta__profile_id"].astype(str).to_numpy(),
        feature_names=np.array(list(shap.columns), dtype=object),
        shap_values=shap.to_numpy(dtype=float),
        expected_value_logit=np.array([additivity["expected_value_logit"]], dtype=float),
    )


def html_escape(text: Any) -> str:
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def write_bar_svg(path: Path, data: pd.DataFrame, label_col: str, value_col: str, title: str, max_rows: int = 20) -> None:
    subset = data.head(max_rows).copy()
    width = 1100
    row_h = 28
    margin_l = 360
    margin_r = 60
    margin_t = 54
    height = margin_t + row_h * len(subset) + 40
    max_value = float(subset[value_col].max()) if len(subset) else 1.0
    max_value = max(max_value, 1e-12)
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="20" y="32" font-family="Arial" font-size="20" font-weight="700">{html_escape(title)}</text>',
    ]
    for i, row in enumerate(subset.itertuples(index=False)):
        label = getattr(row, label_col)
        value = float(getattr(row, value_col))
        y = margin_t + i * row_h
        bar_w = (width - margin_l - margin_r) * value / max_value
        lines.append(f'<text x="20" y="{y + 18}" font-family="Arial" font-size="13">{html_escape(label)}</text>')
        lines.append(f'<rect x="{margin_l}" y="{y + 4}" width="{bar_w:.1f}" height="18" fill="#2f6f8f"/>')
        lines.append(f'<text x="{margin_l + bar_w + 6}" y="{y + 18}" font-family="Arial" font-size="12">{value:.4g}</text>')
    lines.append("</svg>")
    path.write_text("\n".join(lines) + "\n")


def write_direction_svg(path: Path, data: pd.DataFrame, title: str, max_rows: int = 20) -> None:
    subset = data.head(max_rows).copy()
    width = 1200
    row_h = 30
    margin_l = 380
    margin_r = 80
    margin_t = 58
    height = margin_t + row_h * len(subset) + 40
    value_max = float(np.nanmax(np.abs(subset[["mean_shap_apsim_logit", "mean_shap_wofost_logit"]].to_numpy()))) if len(subset) else 1.0
    value_max = max(value_max, 1e-12)
    center = margin_l + (width - margin_l - margin_r) / 2
    scale = (width - margin_l - margin_r) / 2 / value_max
    lines = [
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">',
        '<rect width="100%" height="100%" fill="white"/>',
        f'<text x="20" y="32" font-family="Arial" font-size="20" font-weight="700">{html_escape(title)}</text>',
        f'<line x1="{center:.1f}" y1="{margin_t - 20}" x2="{center:.1f}" y2="{height - 20}" stroke="#444" stroke-width="1"/>',
        f'<text x="{margin_l}" y="{margin_t - 28}" font-family="Arial" font-size="12">APSIM direction</text>',
        f'<text x="{center + 10}" y="{margin_t - 28}" font-family="Arial" font-size="12">WOFOST direction</text>',
    ]
    for i, row in enumerate(subset.itertuples(index=False)):
        y = margin_t + i * row_h
        label = row.feature
        vals = [("APSIM", float(row.mean_shap_apsim_logit), "#b35d3e"), ("WOFOST", float(row.mean_shap_wofost_logit), "#2f6f8f")]
        lines.append(f'<text x="20" y="{y + 19}" font-family="Arial" font-size="13">{html_escape(label)}</text>')
        for _, value, color in vals:
            x0 = center
            x1 = center + value * scale
            x = min(x0, x1)
            w = abs(x1 - x0)
            lines.append(f'<rect x="{x:.1f}" y="{y + 6}" width="{w:.1f}" height="8" fill="{color}" opacity="0.85"/>')
        lines.append(f'<text x="{width - margin_r + 4}" y="{y + 17}" font-family="Arial" font-size="11">{row.mean_shap_apsim_logit:.2g}/{row.mean_shap_wofost_logit:.2g}</text>')
    lines.append("</svg>")
    path.write_text("\n".join(lines) + "\n")


def write_outputs(
    root: Path,
    feature_table: pd.DataFrame,
    predictions: pd.DataFrame,
    shap: pd.DataFrame,
    additivity: dict[str, float],
    global_importance: pd.DataFrame,
    subset: pd.DataFrame,
    groups: pd.DataFrame,
) -> None:
    xai_dir = root / "xai"
    plot_dir = xai_dir / "full_simulation_shap_plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    write_shap_values(root, feature_table, predictions, shap, additivity)
    global_importance.to_csv(xai_dir / "full_simulation_shap_global_importance.csv", index=False)
    global_importance.head(20).to_csv(xai_dir / "full_simulation_shap_top_features.csv", index=False)
    subset.to_csv(xai_dir / "full_simulation_shap_subset_audit.csv", index=False)
    groups.to_csv(xai_dir / "full_simulation_shap_group_summary.csv", index=False)
    write_bar_svg(plot_dir / "global_importance_top20.svg", global_importance, "feature", "mean_abs_shap_logit", "Global mean absolute additive attribution")
    write_direction_svg(plot_dir / "top20_direction_by_class.svg", global_importance, "Top feature direction by true class")
    write_bar_svg(plot_dir / "group_importance.svg", groups, "group", "share_global_importance", "Group-level share of global importance", max_rows=12)


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {k: json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [json_safe(v) for v in value]
    if isinstance(value, tuple):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        value = float(value)
    if isinstance(value, float) and (math.isnan(value) or math.isinf(value)):
        return None
    return value


def write_report(
    root: Path,
    feature_columns: list[str],
    excluded: list[str],
    additivity: dict[str, float],
    global_importance: pd.DataFrame,
    subset: pd.DataFrame,
    groups: pd.DataFrame,
) -> None:
    top10 = global_importance.head(10)
    subset_key = subset.set_index("subset")
    non_maturity_share = float(subset_key.loc["wofost_non_maturity", "total_abs_contribution_share"])
    zero_yield_share = float(subset_key.loc["wofost_zero_yield", "total_abs_contribution_share"])
    short_share = float(subset_key.loc["apsim_short_daily", "total_abs_contribution_share"])
    dominant_statement = (
        "No: the small special-case subsets do not dominate total attribution mass. "
        f"WOFOST non-maturity accounts for {non_maturity_share:.3%}, WOFOST zero-yield for {zero_yield_share:.3%}, "
        f"and APSIM short daily sequences for {short_share:.3%} of total absolute attribution."
    )

    report = f"""# Phase 5.4 SHAP/XAI Report

Date: 2026-07-02

Result package:

`{root}`

Phase gate: **Phase 5.4 complete. Stop here and wait for approval before any manuscript, figure, table, Response Letter, or Supplement integration.**

Final recommendation for downstream manuscript/figure/table integration: **GO**

## 1. Inputs Used

- `features/full_simulation_feature_table.csv`
- `features/full_simulation_feature_dictionary.csv`
- `features/full_simulation_leakage_audit.csv`
- `classifier/full_simulation_classifier_model.pkl`
- `classifier/full_simulation_predictions.csv`
- `classifier/full_simulation_metrics.json`
- `classifier/full_simulation_confusion_matrix.csv`
- `classifier/full_simulation_cv_results.csv`
- `reports/45_CLASSIFIER_REPORT.md`

No simulation outputs, manuscript files, response documents, supplement files, figures, or tables were modified.

## 2. Explanation Method Used and Justification

The Phase 5.3 classifier is a deterministic binary logistic regression trained on a transformed feature matrix. The local runtime does not provide the `shap` package, so this phase used the exact additive attribution for a linear logistic model on the WOFOST logit scale:

`contribution_j = beta_j * (x_j - E[x_j])`

This is SHAP-equivalent for the fitted linear classifier under the observed transformed-feature baseline. One-hot categorical terms and missingness-indicator terms were summed back to their original Phase 5.3 feature names.

Additivity check:

- Expected WOFOST logit: {additivity['expected_value_logit']:.6f}
- Maximum absolute logit additivity error: {additivity['max_additivity_error_logit']:.3e}

Positive attribution pushes the classifier toward WOFOST. Negative attribution pushes it toward APSIM.

## 3. Exact Feature Set Used

The explanation used exactly the 44 leakage-safe classifier features used in Phase 5.3:

{chr(10).join(f'- `{feature}`' for feature in feature_columns)}

## 4. Confirmation of Leakage Exclusions

Excluded from XAI inputs:

- model name
- profile ID
- filenames
- hashes
- target columns
- metadata leakage
- `feature__state_wofost_non_maturity`
- `feature__state_wofost_zero_yield`

The two WOFOST-named state columns were used only to define audit subsets, not as classifier or XAI features.

## 5. Global Top Features

Top 10 features by mean absolute attribution on the WOFOST logit scale:

| Rank | Feature | Group | Mean abs attribution |
|---:|---|---|---:|
{chr(10).join(f"| {int(r.rank)} | `{r.feature}` | {r.group} | {r.mean_abs_shap_logit:.6f} |" for r in top10.itertuples(index=False))}

Full global importance file:

- `xai/full_simulation_shap_global_importance.csv`

## 6. Direction of Top Feature Effects

For the top features, positive values mean movement toward WOFOST and negative values mean movement toward APSIM.

| Rank | Feature | Mean SHAP APSIM | Mean SHAP WOFOST | Class-separation | Direction summary |
|---:|---|---:|---:|---:|---|
{chr(10).join(f"| {int(r.rank)} | `{r.feature}` | {r.mean_shap_apsim_logit:.6f} | {r.mean_shap_wofost_logit:.6f} | {r.class_separation_abs_logit:.6f} | {r.direction_summary} |" for r in top10.itertuples(index=False))}

This table is classifier behavior, not causal crop-model evidence.

Important distinction: global mean absolute attribution measures classifier sensitivity across all profiles. Class-separation attribution, reported as the APSIM-vs-WOFOST mean contribution difference, is the cleaner evidence for model-output signature separation. Shared experimental inputs can have nonzero mean absolute attribution without being a primary APSIM-vs-WOFOST separator.

## 7. Subset Audit Results

| Subset | n | Profile fraction | Total abs attribution share | Top feature | Rank correlation with global |
|---|---:|---:|---:|---|---:|
{chr(10).join(f"| {r.subset} | {int(r.n)} | {r.fraction_of_profiles:.6f} | {r.total_abs_contribution_share:.6f} | `{r.top_feature}` | {r.rank_correlation_with_global_importance if pd.notna(r.rank_correlation_with_global_importance) else 'NA'} |" for r in subset.itertuples(index=False))}

Full subset audit file:

- `xai/full_simulation_shap_subset_audit.csv`

## 8. Dominance Check for Special Subsets

{dominant_statement}

Conclusion: the SHAP-equivalent results are not dominated by WOFOST non-maturity, WOFOST zero-yield, or APSIM short daily-sequence cases.

## 9. Group-Level Interpretation

| Rank | Group | Feature count | Importance share | Class-separation share | Top feature |
|---:|---|---:|---:|---:|---|
{chr(10).join(f"| {int(r.rank)} | {r.group} | {int(r.feature_count)} | {r.share_global_importance:.6f} | {r.share_class_separation:.6f} | `{r.top_feature}` |" for r in groups.itertuples(index=False))}

Full group summary file:

- `xai/full_simulation_shap_group_summary.csv`

## 10. Scientific Interpretation With Strict Caveats

The classifier mainly separates APSIM and WOFOST using differences in simulated output signatures: endpoint yield/output, biomass accumulation, grain accumulation, LAI/canopy behavior, phenology-related states, and daily-window completeness. These are model-output differences from the completed Design B simulation package.

Possible crop-model process interpretation should be limited to cautious hypotheses. These attributions do not prove which internal crop-model process caused the divergence, because the classifier observes simulation outputs and engineered summaries rather than internal process equations.

## 11. SHAP/XAI Scope Statement

This analysis explains the behavior of the Phase 5.3 classifier. It does not establish causal crop-model mechanisms, definitive structural mechanisms, or generalizable process-level claims beyond this Design B full simulation package.

## 12. Recommendation

Recommendation for downstream manuscript/figure/table integration: **GO**.

Rationale:

- The explanation used the same 44 leakage-safe features as Phase 5.3.
- No target, metadata, profile ID, filename, hash, or WOFOST-named leakage feature was used as an XAI input.
- Additive attribution passed the logit additivity check.
- Special-case biological/model stress subsets were retained and audited rather than deleted.
- The special subsets do not dominate total attribution mass.

Use in the manuscript should remain framed as classifier/XAI evidence for model-output signature differences, not as causal proof of internal crop-model mechanisms.

Stop here. Do not modify manuscript, figures, tables, Response Letter, or Supplement until explicit approval is given.
"""
    (root / "reports/46_SHAP_XAI_REPORT.md").write_text(report)


def main(root: Path = ROOT) -> None:
    xai_dir = root / "xai"
    xai_dir.mkdir(exist_ok=True)
    feature_table = pd.read_csv(root / "features/full_simulation_feature_table.csv")
    dictionary = pd.read_csv(root / "features/full_simulation_feature_dictionary.csv")
    predictions = pd.read_csv(root / "classifier/full_simulation_predictions.csv", low_memory=False)
    artifact = load_phase53_model(root)

    feature_columns = list(artifact["selected_features"])
    excluded = list(artifact["excluded_approved_features"])
    if len(feature_table) != 45000 or feature_table["meta__profile_id"].nunique() != 45000:
        raise RuntimeError("Feature table must contain 45,000 unique profiles.")
    if len(feature_columns) != 44:
        raise RuntimeError(f"Expected 44 leakage-safe classifier features, found {len(feature_columns)}.")
    if any(col in EXCLUDED_XAI_FEATURES for col in feature_columns):
        raise RuntimeError("XAI feature set contains a WOFOST-named leakage feature.")
    allowed = set(dictionary.loc[dictionary["allowed_for_classifier"].astype(bool), "column"])
    if not set(feature_columns).issubset(allowed):
        raise RuntimeError("XAI features must be a subset of Phase 5.2 approved features.")
    if len(predictions) != 45000 or predictions["meta__profile_id"].nunique() != 45000:
        raise RuntimeError("Predictions file must contain 45,000 unique profiles.")

    x, transformed_names = transform_feature_table(feature_table, artifact["preprocessor"])
    weights = np.asarray(artifact["model"].weights_, dtype=float)
    if len(weights) != len(transformed_names):
        raise RuntimeError("Model weights do not match transformed feature count.")
    shap, additivity = compute_linear_attributions(
        x=x,
        transformed_names=transformed_names,
        weights=weights,
        bias=float(artifact["model"].bias_),
        source_features=feature_columns,
    )
    global_importance = summarize_global_importance(feature_table, shap, feature_columns)
    subset = subset_audit(feature_table, shap, global_importance)
    groups = group_summary(global_importance)
    write_outputs(root, feature_table, predictions, shap, additivity, global_importance, subset, groups)
    write_report(root, feature_columns, excluded, additivity, global_importance, subset, groups)

    summary = {
        "phase": "5.4 SHAP/XAI",
        "n_rows": int(len(feature_table)),
        "n_unique_profile_ids": int(feature_table["meta__profile_id"].nunique()),
        "feature_count": int(len(feature_columns)),
        "excluded_xai_features": excluded,
        "explanation_method": "linear_logit_additive_attribution_shap_equivalent",
        "expected_value_logit": additivity["expected_value_logit"],
        "max_additivity_error_logit": additivity["max_additivity_error_logit"],
        "top_features": global_importance.head(10).to_dict(orient="records"),
        "subset_audit": subset.to_dict(orient="records"),
        "group_summary": groups.to_dict(orient="records"),
        "recommendation": "GO",
    }
    with open(xai_dir / "full_simulation_shap_xai_summary.json", "w") as f:
        json.dump(json_safe(summary), f, indent=2, allow_nan=False)
        f.write("\n")
    print(json.dumps(json_safe({"top_feature": global_importance.iloc[0]["feature"], "feature_count": len(feature_columns), "max_additivity_error_logit": additivity["max_additivity_error_logit"]}), indent=2))


if __name__ == "__main__":
    main()
