#!/usr/bin/env python3
from pathlib import Path
import json
root = Path(__file__).resolve().parents[1]
for name in ['parallel_smoke_32_summary.json','full_simulation_summary.json']:
    p = root / 'reports' / name
    if p.exists():
        print(json.dumps(json.load(open(p)), indent=2))
