#!/usr/bin/env python3
import subprocess, sys
workers = sys.argv[1] if len(sys.argv) > 1 else '32'
raise SystemExit(subprocess.call([sys.executable, 'scripts/full_simulation_runner.py', '--mode', 'full', '--workers', workers, '--max-retries', '2']))
