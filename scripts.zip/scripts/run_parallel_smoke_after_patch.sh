#!/usr/bin/env bash
set -euo pipefail
cd /root/DesignB_cloud_package
ts=$(date +%Y%m%d_%H%M%S)
backup="reports/smoke_backups/parallel_smoke_32_before_pcse_patch_${ts}"
mkdir -p "$backup"
cp -a reports/parallel_smoke_32* qa/parallel_smoke_32* manifests/status/parallel_smoke_32 "$backup" 2>/dev/null || true
rm -rf manifests/status/parallel_smoke_32
rm -f reports/parallel_smoke_32* qa/parallel_smoke_32* manifests/parallel_smoke_32_sha256_manifest.csv
echo "BACKUP_DIR=$backup"
source venv_designb/bin/activate
export APSIM_CLI=/usr/local/lib/apsim/2026.5.8045.0/bin/Models
python scripts/parallel_smoke_test.py
cat reports/parallel_smoke_32_summary.json
