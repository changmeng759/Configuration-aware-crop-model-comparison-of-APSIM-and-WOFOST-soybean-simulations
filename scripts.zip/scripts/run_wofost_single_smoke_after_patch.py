#!/usr/bin/env python3
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import full_simulation_runner as r  # noqa: E402

namespace = "wofost_single_smoke_after_pcse_patch"
scenarios = r.read_baselines()
perturbations = r.read_perturbations()
paths = r.copy_inputs(scenarios, perturbations)
profiles = r.core.make_profiles(scenarios, perturbations)
target = [p for p in profiles if p["profile_id"] == "W_B0001_P000"]
if len(target) != 1:
    raise SystemExit(f"target count {len(target)}")
result, qa = r.run_profile((target[0], r.pathdict_to_str(paths), namespace, 0))
summary = {
    "namespace": namespace,
    "profile_id": result.get("profile_id"),
    "model": result.get("model"),
    "status": result.get("status"),
    "runtime_s": result.get("runtime_s"),
    "error": result.get("error", ""),
    "daily_csv": result.get("daily_csv", ""),
    "endpoint_json": result.get("endpoint_json", ""),
    "daily_exists": bool(result.get("daily_csv") and Path(result["daily_csv"]).exists()),
    "endpoint_exists": bool(result.get("endpoint_json") and Path(result["endpoint_json"]).exists()),
    "input_qa": qa,
}
# Check NfixTotal availability in daily output header when successful.
if summary["daily_exists"]:
    with open(summary["daily_csv"], "r") as f:
        header = f.readline().strip().split(",")
    summary["daily_header"] = header
    summary["nfix_total_present"] = "NfixTotal" in header
else:
    summary["daily_header"] = []
    summary["nfix_total_present"] = False
out = ROOT / "reports" / "wofost_single_smoke_after_pcse_patch_summary.json"
out.write_text(json.dumps(summary, indent=2))
print(json.dumps(summary, indent=2))
if summary["status"] != "ok":
    raise SystemExit(2)
